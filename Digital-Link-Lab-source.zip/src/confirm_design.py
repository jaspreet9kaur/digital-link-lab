"""Confirm screened candidates with fresh fixed-length batches."""
import csv
import json
import math
from statistics import mean, stdev
from final_study import OUT, BLOCKS, TARGET, measure_fixed, t
from simulate import write_csv


def main():
    path = OUT/'final_design.json'
    d = json.loads(path.read_text())
    with (OUT/'final_ber_summary.csv').open(newline='') as f:
        candidates = [r for r in csv.DictReader(f) if r['qualifies']=='True']
    for r in candidates:
        for field in ('ebno_db','ber','upper95_batch','bandwidth_hz','airtime_ms'):
            r[field] = float(r[field])
        for field in ('payload_bytes','bits','errors'):
            r[field] = int(r[field])
        r['qualifies'] = True
    ordered = sorted(candidates,key=lambda r:(r['ebno_db'],r['bandwidth_hz'],r['airtime_ms']))
    raw, checks = [], []
    for group, s in enumerate(ordered):
        rows = measure_fixed(s['modulation'],s['code'],s['payload_bytes'],s['ebno_db'],1000+group)
        raw.extend(rows)
        v = [r['ber'] for r in rows]
        errors = sum(r['errors'] for r in rows)
        upper = float(mean(v)+t.ppf(.95,BLOCKS-1)*stdev(v)/math.sqrt(BLOCKS)) if errors else None
        check = dict(modulation=s['modulation'],code=s['code'],payload_bytes=s['payload_bytes'],
                     ebno_db=s['ebno_db'],bits=sum(r['bits'] for r in rows),errors=errors,
                     ber=mean(v),upper95_batch=upper,qualifies=upper is not None and upper<=TARGET)
        checks.append(check)
        if check['qualifies']:
            break
    write_csv('final_confirmation_blocks.csv',raw)
    write_csv('final_confirmation_summary.csv',checks)
    if not checks or not checks[-1]['qualifies']:
        raise RuntimeError('No candidate passed independent confirmation.')
    cfg = d['assumptions']
    rx = -174+10*math.log10(d['rate_bps'])+cfg['noise_figure_db']+cfg['margin_db']+s['ebno_db']
    tx = rx+d['loss_db']-cfg['antenna_gain_total_db']
    active = cfg['tx_circuit_w']+10**((tx-30)/10)/cfg['pa_efficiency']
    avg = d['duty']*active+(1-d['duty'])*cfg['idle_w']
    d.update(selected=s,confirmation=check,confirmation_attempts=checks,rx_dbm=rx,tx_dbm=tx,
             active_w=active,average_w=avg,battery_hours=cfg['battery_wh']*cfg['usable_fraction']/avg)
    path.write_text(json.dumps(d,indent=2),encoding='utf-8')
    print(json.dumps(checks,indent=2))

if __name__=='__main__':
    main()
