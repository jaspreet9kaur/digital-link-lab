"""Repeat near-target runs and select a constrained, modeled operating point."""
import csv
import json
import math
from statistics import mean, stdev
import numpy as np
from scipy.stats import t
from simulate import OUT, budget, write_csv, plt
from link import packet

TARGET = 1e-4
RATE = 50_000
MAX_BANDWIDTH = 150_000
MAX_AIRTIME = 0.05
BLOCKS = 20
BITS_PER_BLOCK = 60_000


def measure_fixed(mod, code, size, db, group):
    rows = []
    for block in range(BLOCKS):
        seed = 2026111100 + group*BLOCKS + block
        rng = np.random.default_rng(seed)
        frames = math.ceil(BITS_PER_BLOCK / (8*size))
        errors = bad = 0
        for _ in range(frames):
            payload = rng.integers(0, 2, 8*size, dtype=np.uint8)
            rx, _, _, rate = packet(payload, code, mod, db, rng)
            e = int(np.count_nonzero(payload != rx))
            errors += e
            bad += bool(e)
        bits = frames*8*size
        rows.append(dict(modulation=mod, code=code, payload_bytes=size, ebno_db=db,
                         seed=seed, bits=bits, errors=errors, frames=frames,
                         bad_frames=bad, ber=errors/bits, effective_rate=rate))
    return rows


def main():
    points = [(m,'1/2',s,d) for m in ['QPSK','BPSK'] for s in [64,256]
              for d in [3.25,3.5,3.75,4.0]]
    points += [('QPSK','uncoded',s,d) for s in [64,256] for d in [8.25,8.5,8.75]]
    raw, summaries = [], []
    for g, (mod, code, size, db) in enumerate(points):
        block = measure_fixed(mod,code,size,db,g)
        raw.extend(block)
        ber = mean(r['ber'] for r in block)
        upper = ber+t.ppf(.95,BLOCKS-1)*stdev(r['ber'] for r in block)/math.sqrt(BLOCKS)
        # All-zero batches cannot provide a variance estimate; do not qualify them.
        upper = float(upper) if any(r['errors'] for r in block) else None
        eff = block[0]['effective_rate']
        bw = 1.35*RATE/(eff*(2 if mod=='QPSK' else 1))
        airtime = size*8/RATE
        summaries.append(dict(modulation=mod,code=code,payload_bytes=size,ebno_db=db,
                              bits=sum(r['bits'] for r in block),errors=sum(r['errors'] for r in block),
                              ber=ber,upper95_batch=upper,bandwidth_hz=bw,airtime_ms=1000*airtime,
                              qualifies=upper is not None and upper<=TARGET and bw<=MAX_BANDWIDTH and airtime<=MAX_AIRTIME))
        print(f'{mod} {code} {size} bytes {db:.2f} dB: BER={ber:.3g}, upper={upper}',flush=True)
    write_csv('final_ber_blocks.csv',raw)
    write_csv('final_ber_summary.csv',summaries)
    candidates=[r for r in summaries if r['qualifies']]
    if not candidates:
        raise RuntimeError('No tested configuration qualified; extend the grid before recommending.')
    selected=min(candidates,key=lambda r:(r['ebno_db'],r['bandwidth_hz'],r['airtime_ms']))
    cfg=budget()
    loss=20*math.log10(4*math.pi*cfg['distance_m']*cfg['carrier_mhz']*1e6/299792458)
    rx=-174+10*math.log10(RATE)+cfg['noise_figure_db']+cfg['margin_db']+selected['ebno_db']
    tx=rx+loss-cfg['antenna_gain_total_db']
    duty=cfg['traffic_bps']/RATE
    active=cfg['tx_circuit_w']+10**((tx-30)/10)/cfg['pa_efficiency']
    avg=duty*active+(1-duty)*cfg['idle_w']
    design=dict(selected=selected,assumptions=cfg,rate_bps=RATE,bandwidth_limit_hz=MAX_BANDWIDTH,
                airtime_limit_ms=1000*MAX_AIRTIME,target=TARGET,loss_db=loss,rx_dbm=rx,tx_dbm=tx,
                duty=duty,active_w=active,average_w=avg,battery_hours=cfg['battery_wh']*cfg['usable_fraction']/avg,
                points=len(summaries),tested_bits=sum(r['bits'] for r in raw))
    (OUT/'final_design.json').write_text(json.dumps(design,indent=2),encoding='utf-8')
    fig,ax=plt.subplots(figsize=(9,5))
    for mod in ['QPSK','BPSK']:
        for size in [64,256]:
            subset=[r for r in summaries if r['modulation']==mod and r['payload_bytes']==size and r['code']=='1/2']
            ax.semilogy([r['ebno_db'] for r in subset],[r['upper95_batch'] for r in subset],
                        'o-',label=f'{mod}, {size} B')
    ax.axhline(TARGET,ls='--',color='#b7492a',label='BER target')
    ax.set(xlabel='Payload Eb/N0 (dB)',ylabel='One-sided 95% batch-mean upper estimate',
           title='Repeat trials near the target · rate-1/2 convolutional coding')
    ax.grid(True,which='both',alpha=.25); ax.legend(); fig.tight_layout()
    fig.savefig(OUT/'final_target_ber.png',dpi=150)
    print(json.dumps(design,indent=2),flush=True)

if __name__=='__main__':
    main()
