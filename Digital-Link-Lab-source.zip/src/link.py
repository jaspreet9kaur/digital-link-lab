"""Reusable baseband link. Eb is energy per payload bit, including tail/padding cost."""
import numpy as np
from numba import njit

PATTERNS = {'uncoded': [1], '1/2': [1, 1], '2/3': [1, 1, 1, 0],
            '3/4': [1, 1, 1, 0, 0, 1]}

@njit(cache=True)
def encode(bits):
    out = np.empty(2 * (len(bits) + 6), dtype=np.uint8)
    state = 0
    for t in range(len(bits) + 6):
        bit = int(bits[t]) if t < len(bits) else 0
        reg = (state << 1) | bit
        for j, g in enumerate((0o171, 0o133)):
            v = reg & g
            parity = 0
            while v:
                parity ^= v & 1
                v >>= 1
            out[2*t+j] = parity
        state = reg & 63
    return out

def trellis():
    pred = np.empty((64, 2), dtype=np.int64)
    signs = np.empty((64, 2, 2))
    for s in range(64):
        for k in range(2):
            p = (s >> 1) + 32*k
            pred[s, k] = p
            reg = (p << 1) | (s & 1)
            signs[s, k] = [1 - 2*((reg & g).bit_count() % 2) for g in (0o171, 0o133)]
    return pred, signs

PREDS, SIGNS = trellis()

@njit(cache=True)
def viterbi(soft, pred, signs):
    steps = len(soft)//2
    metrics = np.full(64, 1e100)
    metrics[0] = 0
    paths = np.empty((steps, 64), dtype=np.uint8)
    for t in range(steps):
        new = np.empty(64)
        for s in range(64):
            a = metrics[pred[s, 0]] - soft[2*t]*signs[s, 0, 0] - soft[2*t+1]*signs[s, 0, 1]
            b = metrics[pred[s, 1]] - soft[2*t]*signs[s, 1, 0] - soft[2*t+1]*signs[s, 1, 1]
            pick = 1 if b < a else 0
            new[s] = b if pick else a
            paths[t, s] = pick
        metrics = new
    decoded = np.empty(steps, dtype=np.uint8)
    state = 0  # terminated packet
    for t in range(steps-1, -1, -1):
        decoded[t] = state & 1
        state = pred[state, paths[t, state]]
    return decoded[:-6]

def prepare(bits, code, modulation, rng):
    raw = bits.copy() if code == 'uncoded' else encode(bits)
    mask = np.resize(np.array(PATTERNS[code], dtype=bool), len(raw))
    coded = raw[mask]
    perm = rng.permutation(len(coded))
    stream = coded[perm]
    pad = len(stream) % 2 if modulation == 'QPSK' else 0
    if pad:
        stream = np.append(stream, 0)
    vals = 1.0 - 2.0*stream
    symbols = vals.astype(complex) if modulation == 'BPSK' else (vals[::2]+1j*vals[1::2])/np.sqrt(2)
    return symbols, mask, perm, len(coded), len(bits)/len(stream)

def recover(samples, code, modulation, mask, perm, count):
    soft = samples.real if modulation == 'BPSK' else np.column_stack((samples.real, samples.imag)).ravel()*np.sqrt(2)
    restored = np.empty(count)
    restored[perm] = soft[:count]
    if code == 'uncoded':
        return (restored < 0).astype(np.uint8)
    full = np.zeros(len(mask))  # punctured observations are erasures
    full[mask] = restored
    return viterbi(full, PREDS, SIGNS)

def packet(bits, code, modulation, ebno_db, rng):
    tx, mask, perm, count, rate = prepare(bits, code, modulation, rng)
    k = 1 if modulation == 'BPSK' else 2
    n0 = 1/(rate*k*10**(ebno_db/10))
    rx = tx + np.sqrt(n0/2)*(rng.normal(size=len(tx))+1j*rng.normal(size=len(tx)))
    return recover(rx, code, modulation, mask, perm, count), tx, rx, rate

def rrc(beta=0.35, sps=8, span=12):
    t = np.arange(-span*sps//2, span*sps//2+1)/sps
    h = np.empty(len(t))
    for i, x in enumerate(t):
        if abs(x) < 1e-12:
            h[i] = 1+beta*(4/np.pi-1)
        elif abs(abs(x)-1/(4*beta)) < 1e-12:
            h[i] = beta/np.sqrt(2)*((1+2/np.pi)*np.sin(np.pi/(4*beta))+(1-2/np.pi)*np.cos(np.pi/(4*beta)))
        else:
            h[i] = (np.sin(np.pi*x*(1-beta))+4*beta*x*np.cos(np.pi*x*(1+beta)))/(np.pi*x*(1-(4*beta*x)**2))
    return h/np.sqrt(np.sum(h*h))
