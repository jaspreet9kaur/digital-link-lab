"""Loopback-only UI for the numerical link. No third-party web framework."""
import argparse
import json
import math
import secrets
import threading
import time
from http.cookies import SimpleCookie
from urllib.parse import urlsplit, parse_qs
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import numpy as np
from scipy.signal import upfirdn
from link import prepare, recover, rrc, PATTERNS

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT/'web'
PORT = 8765
ORIGIN = f'http://127.0.0.1:{PORT}'
TOKEN = secrets.token_urlsafe(32)
BUSY = threading.Lock()
LAST_SHARED_RUN = 0.0

def share_config():
    try:
        cfg=json.loads((ROOT/'.share-access.json').read_text(encoding='utf-8-sig'))
        origin=cfg.get('origin','')
        host=urlsplit(origin).netloc
        if not origin.startswith('https://') or not host.endswith('.trycloudflare.com') or '/' in host:
            return {}
        if origin != 'https://'+host or len(cfg.get('key',''))<32: return {}
        return cfg
    except (OSError,ValueError,TypeError): return {}
ASSETS = {'/': WEB/'index.html', '/app.js': WEB/'app.js', '/style.css': WEB/'style.css'}
ASSETS['/story.js']=WEB/'story.js'
ASSETS['/glass.css']=WEB/'glass.css'
ASSETS['/transmission.js']=WEB/'transmission.js'
ASSETS['/transmission.css']=WEB/'transmission.css'
ASSETS['/results/Digital-Link-Lab-Submission.pdf']=ROOT/'output'/'pdf'/'Digital-Link-Lab-Submission.pdf'
for filename in ('final_ber_summary.csv','final_confirmation_summary.csv'):
    ASSETS['/results/'+filename]=ROOT/'results'/filename
for name in ['ber_curves.png','packet_tradeoffs.png','rate_tradeoffs.png','power_battery.png',
             'configuration_summary.csv','ber_measurements.csv','power_tradeoffs.csv','REPORT.md']:
    ASSETS['/results/'+name] = ROOT/'results'/name

def settings(data):
    if not isinstance(data,dict): raise ValueError('Settings must be a JSON object.')
    message=data.get('message')
    if not isinstance(message,str) or not message.strip(): raise ValueError('Enter a message first.')
    if len(message.encode('utf-8'))>4096: raise ValueError('Message must be at most 4096 UTF-8 bytes.')
    mod=data.get('modulation'); code=data.get('code')
    if mod not in ['BPSK','QPSK'] or code not in PATTERNS: raise ValueError('Unsupported modulation or code.')
    for key,choices in [('packet_bytes',[64,256,1024]),('rate_bps',[10000,50000,100000]),('trial_bits',[0,20000,100000])]:
        if type(data.get(key)) is not int or data[key] not in choices: raise ValueError(f'Invalid {key}.')
    seed=data.get('seed'); db=data.get('ebno_db')
    if type(seed) is not int or not 0<=seed<=2147483647: raise ValueError('Seed must be an integer from 0 to 2147483647.')
    if type(db) not in [int,float] or not math.isfinite(db) or not -4<=db<=14: raise ValueError('Eb/N0 must be between -4 and 14 dB.')
    return data

def channel(bits, code, mod, db, rng):
    tx,mask,perm,count,rate=prepare(bits,code,mod,rng)
    h=rrc(); wave=upfirdn(h,tx,up=8)
    n0=1/(rate*(1 if mod=='BPSK' else 2)*10**(db/10))
    noisy=wave+np.sqrt(n0/2)*(rng.normal(size=len(wave))+1j*rng.normal(size=len(wave)))
    matched=np.convolve(noisy,h)
    samples=matched[len(h)-1:len(h)-1+8*len(tx):8]
    decoded=recover(samples,code,mod,mask,perm,count)
    hard=np.array(samples.real<0,dtype=np.uint8) if mod=='BPSK' else np.column_stack((samples.real<0,samples.imag<0)).ravel().astype(np.uint8)
    actual=np.array(tx.real<0,dtype=np.uint8) if mod=='BPSK' else np.column_stack((tx.real<0,tx.imag<0)).ravel().astype(np.uint8)
    before=int(np.count_nonzero(hard[:count]!=actual[:count]))
    return decoded,dict(tx=tx,wave=wave,noisy=noisy,samples=samples,rate=rate,count=count,before=before,n0=n0,
                        trace_tx=actual[:count],trace_rx=hard[:count])

def simulate(data):
    data=settings(data)
    rng=np.random.default_rng(data['seed'])
    raw=data['message'].encode('utf-8'); bits=np.unpackbits(np.frombuffer(raw,dtype=np.uint8))
    parts=[]; first=None; channel_errors=channel_bits=total_symbols=0
    limit=data['packet_bytes']*8
    for start in range(0,len(bits),limit):
        recovered,detail=channel(bits[start:start+limit],data['code'],data['modulation'],data['ebno_db'],rng)
        parts.append(recovered)
        if first is None: first=detail
        channel_errors+=detail['before']; channel_bits+=detail['count']; total_symbols+=len(detail['tx'])
    decoded=np.concatenate(parts); errors=int(np.count_nonzero(decoded!=bits))
    received=np.packbits(decoded).tobytes().decode('utf-8',errors='replace')
    k=1 if data['modulation']=='BPSK' else 2
    effective_rate=len(bits)/(total_symbols*k)
    symbol_rate=data['rate_bps']/(effective_rate*k)
    from simulate import budget
    cfg=budget()
    loss_db=20*np.log10(4*np.pi*cfg['distance_m']*cfg['carrier_mhz']*1e6/299792458)
    rx_dbm=-174+10*np.log10(data['rate_bps'])+cfg['noise_figure_db']+data['ebno_db']+cfg['margin_db']
    tx_dbm=rx_dbm+loss_db-cfg['antenna_gain_total_db']
    duty=cfg['traffic_bps']/data['rate_bps']
    average_w=duty*(cfg['tx_circuit_w']+10**((tx_dbm-30)/10)/cfg['pa_efficiency'])+(1-duty)*cfg['idle_w']
    power=dict(tx_dbm=float(tx_dbm),rx_dbm=float(rx_dbm),path_loss_db=float(loss_db),
               average_w=float(average_w),battery_hours=cfg['battery_wh']*cfg['usable_fraction']/average_w,
               assumptions=cfg,duty_cycle=duty)
    curves=[]
    if data['trial_bits']:
        # Independent generated payloads; symbol-domain equivalent used for fast trials.
        from link import packet
        from scipy.stats import beta
        for code in list(dict.fromkeys(['uncoded',data['code']])):
            trial_rng=np.random.default_rng(data['seed']+100)
            tested=err=packets=packet_errors=0
            while tested<data['trial_bits']:
                n=min(limit,data['trial_bits']-tested)
                b=trial_rng.integers(0,2,n,dtype=np.uint8)
                d,*_=packet(b,code,data['modulation'],data['ebno_db'],trial_rng)
                e=int(np.count_nonzero(b!=d)); tested+=n; err+=e; packets+=1; packet_errors+=e>0
            upper=1.0 if err==tested else float(beta.ppf(.975,err+1,tested-err))
            curves.append(dict(code=code,bits=tested,errors=err,ber=err/tested,upper95=upper,packet_errors=packet_errors,packets=packets))
    def series(v): return [float(x) for x in v]
    return dict(settings=data,received=received,bytes=len(raw),bits=len(bits),errors=errors,ber=errors/len(bits),
                message_ok=errors==0,packets=len(parts),channel_errors=channel_errors,channel_bits=channel_bits,
                coded_bits=channel_bits,effective_rate=effective_rate,symbols=total_symbols,
                power=power,
                duration_ms=1000*len(bits)/data['rate_bps'],bandwidth_hz=1.35*symbol_rate,
                tx_bits=bits[:128].tolist(),rx_bits=decoded[:128].tolist(),
                trace=dict(transmitted_bits=first['trace_tx'][:48].tolist(),channel_bits=first['trace_rx'][:48].tolist()),
                constellation=dict(i=series(first['samples'].real[:800]),q=series(first['samples'].imag[:800])),
                waveform=dict(tx=series(first['wave'].real[:400]),rx=series(first['noisy'].real[:400])),
                comparison=curves,
                note='Message uses actual RRC TX/channel/matched-filter samples with ideal timing and carrier. Comparison trials use the equivalent symbol-domain model. No hardware measurements. Duration excludes framing and filter transients.')

class Handler(BaseHTTPRequestHandler):
    def setup(self):
        super().setup()
        self.connection.settimeout(10)
    def log_message(self,*args): pass  # never log message payloads
    def send(self,status,body,kind='application/json'):
        if isinstance(body,dict): body=json.dumps(body,allow_nan=False).encode()
        self.send_response(status); self.send_header('Content-Type',kind)
        self.send_header('Content-Length',str(len(body))); self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'")
        self.send_header('Referrer-Policy','no-referrer'); self.end_headers(); self.wfile.write(body)
    def is_shared(self): return self.headers.get('Host')!=f'127.0.0.1:{PORT}'
    def valid_host(self):
        host=self.headers.get('Host')
        if host==f'127.0.0.1:{PORT}': return True
        cfg=share_config()
        return bool(cfg) and host in ['digital-link-lab-tunnel',urlsplit(cfg['origin']).netloc]
    def share_authenticated(self):
        if not self.is_shared(): return True
        cfg=share_config()
        if not cfg:return False
        try:
            cookies=SimpleCookie();cookies.load(self.headers.get('Cookie',''))
            value=cookies['lab_share'].value if 'lab_share' in cookies else ''
            return secrets.compare_digest(value,cfg['key'])
        except Exception:return False
    def do_GET(self):
        if not self.valid_host(): self.send(403,dict(error='Invalid host.')); return
        if self.is_shared():
            cfg=share_config();parts=urlsplit(self.path)
            access=parse_qs(parts.query).get('access',[''])[0]
            if parts.path=='/' and access and secrets.compare_digest(access,cfg.get('key','')):
                self.send_response(303);self.send_header('Location','/')
                self.send_header('Set-Cookie','lab_share='+cfg['key']+'; Path=/; Secure; HttpOnly; SameSite=Strict; Max-Age=86400')
                self.send_header('Cache-Control','no-store');self.send_header('Referrer-Policy','no-referrer')
                self.send_header('Content-Length','0');self.end_headers();return
            if not self.share_authenticated():
                self.send(403,dict(error='Please use the full private invitation link supplied by the project owner.'));return
        if self.path=='/api/session':
            if self.headers.get('Sec-Fetch-Site')=='cross-site': self.send(403,dict(error='Cross-site request denied.')); return
            self.send(200,dict(token=TOKEN)); return
        if self.path=='/api/health': self.send(200,dict(status='ready',app='digital-link-lab')); return
        path=ASSETS.get(self.path)
        if path is None or not path.is_file(): self.send(404,dict(error='Not found.')); return
        kind={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.csv':'text/csv; charset=utf-8','.md':'text/plain; charset=utf-8','.pdf':'application/pdf'}[path.suffix]
        self.send(200,path.read_bytes(),kind)
    def do_POST(self):
        global LAST_SHARED_RUN
        expected_origin=share_config().get('origin') if self.is_shared() else ORIGIN
        if not self.valid_host() or not self.share_authenticated() or self.headers.get('Origin')!=expected_origin or self.headers.get('X-Lab-Token')!=TOKEN:
            self.send(403,dict(error='Open the application locally to run an experiment.')); return
        if self.path!='/api/simulate': self.send(404,dict(error='Not found.')); return
        if self.headers.get('Content-Type')!='application/json': self.send(415,dict(error='JSON required.')); return
        try: size=int(self.headers.get('Content-Length','0'))
        except ValueError: self.send(400,dict(error='Invalid request length.')); return
        if not 0<size<=20000: self.send(413,dict(error='Request too large or empty.')); return
        if not BUSY.acquire(blocking=False): self.send(429,dict(error='Another experiment is running. Try again shortly.')); return
        try:
            if self.is_shared():
                now=time.monotonic()
                if now-LAST_SHARED_RUN<2:
                    self.send(429,dict(error='Please wait two seconds between shared experiments.'));return
                LAST_SHARED_RUN=now
            self.connection.settimeout(10)
            data=json.loads(self.rfile.read(size))
            result=simulate(data)
            self.send(200,result)
        except (ValueError,UnicodeError,TimeoutError): self.send(400,dict(error='Invalid inputs. Check the message and settings.'))
        except Exception: self.send(500,dict(error='Simulation failed. Restart the app and try again.'))
        finally: BUSY.release()

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--open',action='store_true',help='Open the default browser once the server is ready')
    args=parser.parse_args()
    server=ThreadingHTTPServer(('127.0.0.1',PORT),Handler)
    server.daemon_threads=True
    print(f'Digital Link Lab: {ORIGIN}',flush=True)
    print('Keep this process open. Press Ctrl+C to stop.',flush=True)
    if args.open:
        import webbrowser
        threading.Timer(.5,lambda:webbrowser.open(ORIGIN)).start()
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
