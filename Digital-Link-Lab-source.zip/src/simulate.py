"""Offline Monte Carlo simulation; bounded local outputs only, no radio/network I/O."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.special import erfc
from scipy.stats import beta
from scipy.signal import upfirdn, welch
from link import packet, prepare, recover, rrc, PATTERNS

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'results'
TARGET = 1e-4

def budget():
    values=json.loads((ROOT/'configs'/'link_budget.json').read_text(encoding='utf-8'))
    required=['carrier_mhz','distance_m','noise_figure_db','margin_db','antenna_gain_total_db',
              'battery_wh','usable_fraction','tx_circuit_w','idle_w','pa_efficiency','traffic_bps']
    if set(values) != set(required): raise ValueError('Unexpected or missing budget setting')
    for key,value in values.items():
        if isinstance(value,bool) or not isinstance(value,(int,float)) or not np.isfinite(value):
            raise ValueError(f'{key} must be a finite number')
    for key in ['carrier_mhz','distance_m','battery_wh','traffic_bps']:
        if values[key]<=0: raise ValueError(f'{key} must be positive')
    for key in ['usable_fraction','pa_efficiency']:
        if not 0<values[key]<=1: raise ValueError(f'{key} must be between 0 and 1')
    for key in ['noise_figure_db','margin_db','tx_circuit_w','idle_w']:
        if values[key]<0: raise ValueError(f'{key} cannot be negative')
    if values['traffic_bps']>10000: raise ValueError('Traffic must not exceed lowest tested useful rate: 10000 bit/s')
    return values

def interval(e, n):
    return (0.0 if e == 0 else float(beta.ppf(.025, e, n-e+1)),
            1.0 if e == n else float(beta.ppf(.975, e+1, n-e)))

def measure(code, mod, size, db, cap, seed):
    rng = np.random.default_rng(seed)
    errors = bits = failures = frames = 0
    while bits < cap and errors < 200:
        data = rng.integers(0, 2, size*8, dtype=np.uint8)
        decoded, _, _, rate = packet(data, code, mod, db, rng)
        e = int(np.count_nonzero(decoded != data))
        errors += e; bits += len(data); failures += e > 0; frames += 1
    lo, hi = interval(errors, bits)
    return dict(code=code, modulation=mod, payload_bytes=size, ebno_db=db,
                errors=errors, bits=bits, ber=errors/bits, ci_low=lo, ci_high=hi,
                packets=frames, packet_errors=failures, per=failures/frames,
                effective_rate=rate, seed=seed)

def write_csv(name, rows):
    if rows:
        with (OUT/name).open('w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0]))
            writer.writeheader(); writer.writerows(rows)

def crossing(rows):
    r = sorted(rows, key=lambda x:x['ebno_db'])
    for a, b in zip(r, r[1:]):
        if a['ber'] > TARGET and 0 < b['ber'] <= TARGET:
            fraction = (np.log10(TARGET)-np.log10(a['ber']))/(np.log10(b['ber'])-np.log10(a['ber']))
            return a['ebno_db']+fraction*(b['ebno_db']-a['ebno_db']), 'log-BER interpolation; point estimate'
        if a['ber'] > TARGET and b['ber'] == 0 and b['ci_high'] <= TARGET:
            return b['ebno_db'], 'tested conservative grid point; zero-error upper bound'
    return None, 'unresolved within sweep'

def waveform():
    rng = np.random.default_rng(75)
    bits = rng.integers(0, 2, 2048, dtype=np.uint8)
    tx, mask, perm, count, rate = prepare(bits, '1/2', 'QPSK', rng)
    h = rrc(); wave = upfirdn(h, tx, up=8)
    # Known, compensated path loss; ideal timing/carrier. Noise added AFTER loss.
    loss = 10**(-60/20); db = 4.0
    n0 = loss**2/(2*rate*10**(db/10))
    noisy = loss*wave + np.sqrt(n0/2)*(rng.normal(size=len(wave))+1j*rng.normal(size=len(wave)))
    filtered = np.convolve(noisy, h)/loss
    samples = filtered[len(h)-1:len(h)-1+8*len(tx):8]
    decoded = recover(samples, '1/2', 'QPSK', mask, perm, count)
    fig, axes = plt.subplots(2,2, figsize=(12,8))
    axes[0,0].plot(wave.real[:400], label='I'); axes[0,0].plot(wave.imag[:400],label='Q'); axes[0,0].legend(); axes[0,0].set_title('RRC shaped TX waveform')
    axes[0,1].scatter(samples.real[:1500],samples.imag[:1500],s=3,alpha=.3); axes[0,1].scatter(tx.real,tx.imag,s=20,color='black'); axes[0,1].set_title('Matched-filter QPSK constellation at 4 dB')
    f,p = welch(wave, fs=8, return_onesided=False, nperseg=512)
    order=np.argsort(f); axes[1,0].plot(f[order],10*np.log10(p[order]+1e-15)); axes[1,0].set_title('Baseband spectrum'); axes[1,0].set_xlabel('Frequency / symbol rate')
    axes[1,1].step(np.arange(64),bits[:64],label='Original'); axes[1,1].step(np.arange(64),decoded[:64]+.05,label='Recovered'); axes[1,1].legend(); axes[1,1].set_title(f'Recovered payload: {np.count_nonzero(bits != decoded)} errors / {len(bits)} bits')
    fig.tight_layout(); fig.savefig(OUT/'waveform_demo.png',dpi=150); plt.close(fig)
    np.savez_compressed(OUT/'waveform_demo.npz',original=bits,recovered=decoded,tx_samples=wave,rx_symbols=samples)

def run(profile):
    cfg=budget()
    OUT.mkdir(exist_ok=True)
    cap = 120_000 if profile == 'quick' else 1_200_000
    sizes = [64,256] if profile == 'quick' else [64,256,1024]
    rows=[]
    for size in sizes:
        for mod in ['BPSK','QPSK']:
            for code in PATTERNS:
                for db in ([0,2,3,4,5,6,7,8,9] if code != 'uncoded' else [0,2,4,6,7,8,9]):
                    row=measure(code,mod,size,db,cap,20261014+len(rows))
                    rows.append(row)
                print(f'{size} bytes {mod} {code}: completed',flush=True)
                write_csv('ber_measurements.csv',rows)
    fig,axes=plt.subplots(1,len(sizes),figsize=(7*len(sizes),5),squeeze=False)
    summary=[]
    for size,ax in zip(sizes,axes[0]):
        for mod in ['BPSK','QPSK']:
            baseline,_=crossing([r for r in rows if r['payload_bytes']==size and r['modulation']==mod and r['code']=='uncoded'])
            for code in PATTERNS:
                subset=[r for r in rows if r['payload_bytes']==size and r['modulation']==mod and r['code']==code]
                x=[r['ebno_db'] for r in subset]; y=[r['ber'] if r['errors'] else r['ci_high'] for r in subset]
                ax.semilogy(x,y,('o-' if mod=='BPSK' else 's--'),label=f'{mod} {code}')
                required,status=crossing(subset)
                summary.append(dict(payload_bytes=size,modulation=mod,code=code,required_ebno_db=required,
                                    coding_gain_db=None if required is None or baseline is None else baseline-required,status=status,
                                    effective_rate=subset[0]['effective_rate']))
        x=np.linspace(0,9,100); ax.semilogy(x,.5*erfc(np.sqrt(10**(x/10))),'k:',label='Uncoded theory')
        ax.axhline(TARGET,color='gray'); ax.set(xlabel='Payload Eb/N0 (dB)',ylabel='BER (zero errors: 95% upper bound)',title=f'{size}-byte packets'); ax.grid(True,which='both',alpha=.3); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(OUT/'ber_curves.png',dpi=150); plt.close(fig)
    write_csv('configuration_summary.csv',summary)
    trade=[]
    for s in summary:
        if s['required_ebno_db'] is None: continue
        for rb in [10_000,50_000,100_000]:
            # 915 MHz / 100 m free-space example, not a measured radio link.
            pathloss=20*np.log10(4*np.pi*cfg['distance_m']*cfg['carrier_mhz']*1e6/299792458)
            rx=-174+10*np.log10(rb)+cfg['noise_figure_db']+s['required_ebno_db']+cfg['margin_db']
            tx=rx+pathloss-cfg['antenna_gain_total_db']
            rf_w=10**((tx-30)/10)
            # Traffic = 1000 payload bit/s, active circuitry=.5 W; idle=.01 W.
            duty=cfg['traffic_bps']/rb; avg=duty*(cfg['tx_circuit_w']+rf_w/cfg['pa_efficiency'])+(1-duty)*cfg['idle_w']
            trade.append(dict(**s,useful_rate_bps=rb,required_rx_dbm=rx,modeled_tx_dbm=tx,
                              bandwidth_hz=1.35*rb/(s['effective_rate']*(1 if s['modulation']=='BPSK' else 2)),
                              duty_cycle=duty,modeled_average_w=avg,estimated_battery_hours=cfg['battery_wh']*cfg['usable_fraction']/avg))
    write_csv('power_tradeoffs.csv',trade)
    fig,axes=plt.subplots(1,2,figsize=(12,5))
    for code in PATTERNS:
        subset=[r for r in trade if r['payload_bytes']==256 and r['modulation']=='BPSK' and r['code']==code]
        axes[0].plot([r['useful_rate_bps']/1000 for r in subset],[r['modeled_tx_dbm'] for r in subset],'o-',label=code)
        axes[1].plot([r['useful_rate_bps']/1000 for r in subset],[r['estimated_battery_hours'] for r in subset],'o-',label=code)
    axes[0].set(xlabel='Useful rate (kbit/s)',ylabel='Modeled TX power (dBm)',title='256-byte BPSK: modeled required RF power')
    axes[1].set(xlabel='Useful rate (kbit/s)',ylabel='Estimated battery hours',title='Assumed battery / circuitry / duty cycle')
    for ax in axes: ax.grid(alpha=.3); ax.legend()
    fig.tight_layout(); fig.savefig(OUT/'power_battery.png',dpi=150); plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,5))
    for size in sizes:
        for code in PATTERNS:
            subset=[s for s in summary if s['payload_bytes']==size and s['modulation']=='BPSK' and s['code']==code and s['required_ebno_db'] is not None]
            if subset: ax.plot([10,50,100],[subset[0]['required_ebno_db']]*3,'o-',label=f'{size} B, {code}')
    ax.set(xlabel='Useful data rate (kbit/s)',ylabel='Required payload Eb/N0 (dB)',title='Ideal AWGN: normalized Eb/N0 independent of data rate'); ax.legend(fontsize=8); ax.grid(alpha=.3); fig.tight_layout(); fig.savefig(OUT/'rate_tradeoffs.png',dpi=150); plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,5))
    for mod in ['BPSK','QPSK']:
        for code in PATTERNS:
            subset=[s for s in summary if s['modulation']==mod and s['code']==code and s['required_ebno_db'] is not None]
            ax.plot([s['payload_bytes'] for s in subset],[s['required_ebno_db'] for s in subset],'o-',label=f'{mod} {code}')
    ax.set(xlabel='Payload bytes',ylabel='Required payload Eb/N0 (dB)',title='Packet size and coding termination overhead'); ax.legend(fontsize=8); ax.grid(alpha=.3); fig.tight_layout(); fig.savefig(OUT/'packet_tradeoffs.png',dpi=150); plt.close(fig)
    waveform()
    best=min(trade,key=lambda r:r['modeled_average_w']) if trade else None
    assumptions=dict(profile=profile,max_bits_per_point=cap,target_errors=200,seed=20261014,target_ber=TARGET,
                     **cfg,
                     ideal_timing=True,ideal_carrier=True,no_preamble_or_crc=True)
    (OUT/'run_metadata.json').write_text(json.dumps(assumptions,indent=2),encoding='utf-8')
    text='# Stage 1 simulation results\n\nGenerated from actual Monte Carlo runs. No hardware measurements.\n\n'
    text+=f'Profile: {profile}; {len(rows)} BER points; up to {cap:,} payload bits per point; stop after 200 errors. See CSV for exact counts.\n\n'
    text+='Target crossings are interpolated point estimates, or conservative tested grid points. Confidence intervals are exact binomial intervals; decoded error bursts violate the independence approximation, so intervals are indicative for coded BER. They are not certification. Zero errors are plotted at their upper bound.\n\n'
    text+='Coding: K=7, 171/133 octal, zero-start, six zero tail bits, puncturing, packet permutation interleaving, soft Viterbi. Payload Eb includes termination/padding cost. Sweeps use the equivalent ideal matched-filter symbol model; waveform demo separately implements RRC TX/RX filters and compensated 60 dB attenuation.\n\n'
    text+='Assumptions: perfect timing/carrier/channel-gain knowledge; no fading, interference, preamble, CRC, synchronization acquisition, retries or processing-energy measurement. Source is generated bits (identity source encoding). Stage 2 must add framing and synchronization.\n\n'
    text+='Power/battery assumptions from configs/link_budget.json:\n\n```json\n'+json.dumps(cfg,indent=2)+'\n```\n\nFree-space propagation at approximately 290 K; no retransmissions or processing energy. All budget inputs are assumptions. Recommendations change when these inputs change. Data-rate curves reuse the normalized AWGN measurement, not independent rate simulations.\n\n'
    if best:
        text+=f"Lowest modeled average-power candidate: {best['modulation']}, code {best['code']}, {best['payload_bytes']} bytes, {best['useful_rate_bps']} bit/s; {best['modeled_average_w']:.4f} W, estimated {best['estimated_battery_hours']:.1f} h. Provisional: bandwidth/latency constraints and real circuit consumption are unspecified.\n"
        low_rf=min(trade,key=lambda r:r['modeled_tx_dbm'])
        text+=f"\nMinimum modeled radiated-power candidate: {low_rf['modulation']}, code {low_rf['code']}, {low_rf['payload_bytes']} bytes, {low_rf['useful_rate_bps']} bit/s; {low_rf['modeled_tx_dbm']:.2f} dBm. This is distinct from minimum average electrical power.\n"
    text+='\n## Measured configuration comparison\n\n| Payload bytes | Modulation | Code | Required Eb/N0 dB | Coding gain dB |\n|---|---|---|---|---|\n'
    for s in summary:
        req='unresolved' if s['required_ebno_db'] is None else f"{s['required_ebno_db']:.2f}"
        gain='unresolved' if s['coding_gain_db'] is None else f"{s['coding_gain_db']:.2f}"
        text+=f"| {s['payload_bytes']} | {s['modulation']} | {s['code']} | {req} | {gain} |\n"
    text+='\nConsult run_metadata.json for the actual budget settings; defaults can be edited in configs/link_budget.json.\n'
    (OUT/'REPORT.md').write_text(text,encoding='utf-8')

if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--profile',choices=['quick','full'],default='quick')
    run(parser.parse_args().profile)
