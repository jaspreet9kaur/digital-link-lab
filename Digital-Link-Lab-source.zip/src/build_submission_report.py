"""Generate the printable submission report from verified simulation artifacts."""
import csv
import json
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'results'
d = json.loads((OUT/'final_design.json').read_text())
s, c = d['selected'], d['confirmation']
assert c['qualifies'] and c['ebno_db']==s['ebno_db']
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name='BodyLab',fontName='Helvetica',fontSize=10.5,leading=15,spaceAfter=9,textColor=colors.HexColor('#26354b')))
styles.add(ParagraphStyle(name='KickerLab',fontName='Helvetica-Bold',fontSize=10,leading=14,spaceAfter=10,textColor=colors.HexColor('#167d83')))
styles['Heading1'].textColor=colors.HexColor('#172f52')
styles['Title'].textColor=colors.HexColor('#172f52')
parts=[]

def p(t, style='BodyLab'):
    parts.append(Paragraph(t,styles[style]))

def title(n,t):
    p(n,'KickerLab'); p(t,'Heading1')

def tab(rows,widths):
    table=Table([[Paragraph(escape(str(v)),styles['BodyLab']) for v in row] for row in rows],colWidths=widths)
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dcecf1')),
                               ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f2f6fb')]),
                               ('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),8),
                               ('BOTTOMPADDING',(0,0),(-1,-1),2)]))
    parts.append(table); parts.append(Spacer(1,11))

def fig(name,w,h):
    parts.append(Image(str(OUT/name),width=w,height=h))
    parts.append(Spacer(1,8))

def page():
    parts.append(PageBreak())

p('DIGITAL COMMUNICATIONS  /  GROUP 3','KickerLab')
p('Low-Power Digital Link','Title')
p('For soldier and vehicle nodes | Simulation submission | 11 November 2026')
p('Objective: identify a low-transmit-power configuration that reaches a payload bit error rate (BER) of 10^-4, then justify the selection with a link budget and a battery-life estimate.')
title('01 / RECOMMENDATION','Use QPSK with rate-1/2 convolutional coding')
tab([['Parameter','Recommended setting or result'],
     ['Payload / useful rate',f"{s['payload_bytes']} bytes / {d['rate_bps']/1000:.0f} kbit/s"],
     ['Payload Eb/N0',f"{s['ebno_db']:.2f} dB"],
     ['Estimated bandwidth / payload airtime',f"{s['bandwidth_hz']/1000:.1f} kHz / {s['airtime_ms']:.2f} ms"],
     ['Independent confirmation',f"{c['errors']} errors / {c['bits']:,} payload bits"],
     ['BER / approximate one-sided upper estimate',f"{c['ber']:.3g} / {c['upper95_batch']:.3g}"],
     ['Modeled RF output / battery estimate',f"{d['tx_dbm']:.2f} dBm / {d['battery_hours']:.0f} h"]],[204,291])
p('Selection limits: 50 kbit/s useful rate, at most 150 kHz estimated occupied bandwidth and at most 50 ms payload airtime. These are declared design assumptions, not requirements supplied by the instructor.')
p('The recommendation is the lowest independently confirmed point in the screened set, under the chosen model and grid. Its battery estimate applies to the same configuration. It is not a hardware measurement or a certified BER guarantee.')
p('Demonstration: <link href="https://digital-link-lab-ankur.wavydove8.chatgpt.site/" color="#12638b">Open Digital Link Lab</link>. Use noise with and without protection, then show the BER tradeoffs. The short live message is a functional demo; the fixed-length experiments establish the numerical result.')
page()
title('02 / LINK DESIGN','Signal chain and experimental method')
p('<b>Transmit:</b> digital payload (UTF-8 text or generated test bits)  &gt;  convolutional encoder  &gt;  seeded interleaver  &gt;  BPSK or QPSK mapping  &gt;  root-raised-cosine pulse shaping.')
p('<b>Receive:</b> Gaussian-noise channel  &gt;  matched filter and demodulation  &gt;  deinterleaver  &gt;  soft Viterbi decoder  &gt;  reconstructed payload and bit-error count. The waveform demo has a fixed attenuation case; the budget models free-space path loss.')
p('The convolutional code has constraint length 7, generator polynomials 171 and 133 (octal), and six tail bits per coded packet. Puncturing provides rate 2/3 and 3/4 alternatives. Noise is normalized to energy per useful payload bit, including coding overhead. The numerical sweeps use the ideal matched-filter symbol-domain equivalent. The interactive demo evaluates actual shaped waveform samples.')
p('The broad screen used 204 operating points over BPSK/QPSK, uncoded plus three code rates, 64/256/1024-byte packets and an Eb/N0 sweep. The 10/50/100 kbit/s budget comparison converts required payload Eb/N0 into RF power. In ideal AWGN, changing rate alone does not alter normalized BER.')
fig('ber_curves.png',495,118)
p('Figure 1. Original BER sweep, including the uncoded reference and target line. Data files: ber_measurements.csv, configuration_summary.csv and power_tradeoffs.csv.')
fig('packet_tradeoffs.png',370,205)
p('Figure 2. Original packet-size comparison. These interpolated crossings are estimates; the final selection uses repeat batches and independent confirmation.')
page()
title('03 / VALIDATION','Why the lowest screening result was rejected')
p(f"The near-target study ran {d['points']} settings and {d['tested_bits']:,} payload bits, with 20 independent fixed-length batches per setting. The one-sided 95% upper estimate uses the variance of batch BER means, so it does not treat every bit in a Viterbi error burst as independent. It is still an approximate interval, especially with few error events.")
tab([['Confirmation candidate','Fresh bits','Errors','BER','Upper estimate'],
     *[[f"{r['modulation']} 1/2, {r['ebno_db']:.2f} dB",f"{r['bits']:,}",r['errors'],f"{r['ber']:.3g}",f"{r['upper95_batch']:.3g}"] for r in d['confirmation_attempts']]],[167,87,61,83,97])
p('The initial BPSK candidate at 3.50 dB did not reproduce its screening result. The next candidate, QPSK at 3.75 dB, passed on fresh seeds and meets the bandwidth and airtime limits. This does not establish that QPSK intrinsically has better BER than BPSK in ideal AWGN; sampling uncertainty matters. QPSK uses fewer symbols for the same bit rate.')
p('For 256-byte QPSK packets, the lowest qualifying uncoded point in the repeat sweep was 8.50 dB. The confirmed coded operating point is 3.75 dB, a <b>4.75 dB tested operating-point difference</b>. The original interpolated target-crossing estimate for this same comparison was 4.91 dB; those numbers measure different things.')
fig('final_target_ber.png',495,275)
p('Figure 3. Repeat-screen upper estimates for the four rate-1/2 combinations. Independent confirmation is reported in the table above.')
page()
title('04 / LINK BUDGET','One configuration, from RF power to runtime')
p('Example assumptions: 915 MHz, 100 m free space, 0 dB total antenna gain, 6 dB receiver noise figure, 3 dB implementation margin, 50 kbit/s useful bit rate. The carrier is a budget assumption; it is not approval to transmit over the air.')
tab([['Step','Worked calculation'],
     ['Free-space path loss',f"20 log10(4 pi d f / c) = {d['loss_db']:.2f} dB"],
     ['Required received power',f"-174 + 10 log10(50,000) + 6 + 3 + 3.75 = {d['rx_dbm']:.2f} dBm"],
     ['Modeled transmit power',f"{d['rx_dbm']:.2f} + {d['loss_db']:.2f} - 0 = {d['tx_dbm']:.2f} dBm"],
     ['TX duty cycle','1,000 bit/s average traffic / 50,000 bit/s useful active rate = 2%'],
     ['Average node electrical power',f"2%  x  active power + 98%  x  10 mW idle = {d['average_w']*1000:.2f} mW"],
     ['Estimated battery life',f"10 Wh  x  80% usable / {d['average_w']:.4f} W = {d['battery_hours']:.0f} hours (about {d['battery_hours']/24:.1f} days)"]],[199,296])
p('Active model: 0.5 W circuitry plus RF output divided by 25% amplifier efficiency. The modeled electronics and duty cycle dominate the estimate. No circuit power, battery discharge, antenna loss, fading, interference or range was measured. Actual gain steps may not reach the very low modeled TX output directly; bench attenuation and calibration must be reported separately.')
title('05 / HARDWARE HANDOFF','Minimum bench setup and remaining work')
p('Existing laptop, bladeRF TX, RTL-SDR RX and spectrum analyzer; compatible USB data cables, 50-ohm SMA path with rated attenuation and any adapters, one suitable current-measuring supply or data-pass-through USB power meter, and a compatible battery pack for the physical demonstration.')
p('Before enabling TX, confirm model-specific input limits, frequency overlap, safe attenuation and bias-tee state with the lab. Record calibrated RF output separately from DC watts at each gain step. Physical framing and synchronization, gain calibration, current logging and the battery demo are pending.')
p('Tools used: Python, NumPy, SciPy, Matplotlib and a browser worker. MATLAB/Simulink and GNU Radio were not used for these results. GNU Radio or equivalent model-compatible SDR software belongs to the bench phase.')
p('Reproduce: run src/final_study.py, then src/confirm_design.py in the project environment. Raw batch data, confirmation CSV and final_design.json preserve the result. Basis: supplied project brief, original simulation artifacts and independent repeat runs.')
page()
title('06 / COMPARISON TABLE','Modeled RF power at the target BER')
p('Original screening estimates at 50 kbit/s and 256-byte payloads. Required Eb/N0 is interpolated from the original BER curves. These rows are useful for comparison; the final recommendation uses a tested grid point and fresh confirmation.')
with (OUT/'power_tradeoffs.csv').open(newline='') as f:
    comparison = [r for r in csv.DictReader(f)
                  if r['useful_rate_bps']=='50000' and r['payload_bytes']=='256']
tab([['Modulation','Code','Eb/N0 (dB)','RF output (dBm)','Bandwidth (kHz)'],
     *[[r['modulation'],r['code'],f"{float(r['required_ebno_db']):.2f}",
        f"{float(r['modeled_tx_dbm']):.2f}",f"{float(r['bandwidth_hz'])/1000:.1f}"]
       for r in comparison]],[92,65,104,118,116])
fig('rate_tradeoffs.png',425,236)
p('Figure 4. Required normalized Eb/N0 versus useful data rate. The ideal AWGN curves are flat because the rate is accounted for in the power conversion, not by changing the normalized channel model. See power_tradeoffs.csv for modeled RF power at every evaluated rate and packet size.')

def footer(canvas, doc):
    canvas.setStrokeColor(colors.HexColor('#dbe4ef')); canvas.line(50,39,545,39)
    canvas.setFillColor(colors.HexColor('#536781')); canvas.setFont('Helvetica',8)
    canvas.drawString(50,25,'DIGITAL LINK LAB   /   SIMULATION SUBMISSION')
    canvas.drawRightString(545,25,str(doc.page))

target=ROOT/'output'/'pdf'/'Digital-Link-Lab-Submission.pdf'
target.parent.mkdir(parents=True,exist_ok=True)
SimpleDocTemplate(str(target),pagesize=A4,leftMargin=50,rightMargin=50,topMargin=46,bottomMargin=53,
                  title='Low-Power Digital Link - Simulation Submission').build(parts,onFirstPage=footer,onLaterPages=footer)
print(target)
