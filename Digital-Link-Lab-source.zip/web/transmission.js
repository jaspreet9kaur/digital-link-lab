'use strict';
// Animated explanatory playback of actual computed bits. No fabricated errors.
const visual={data:null,time:0,playing:false,lastClock:0,total:18,frame:0};
const canvas=document.getElementById('transmission-canvas'),ctx=canvas.getContext('2d');
const captions=[['Your message becomes digital data',''],['Add protection and interleave',''],['Transmit a shaped signal through noise',''],['Receive, filter and recover bits',''],['The recovered message arrives','']];
function visualStage(){return Math.min(4,Math.floor(visual.time/(visual.total/5)))}
function paint(){
 const width=canvas.clientWidth||600,height=canvas.clientHeight||270,scale=window.devicePixelRatio||1;
 if(canvas.width!==Math.round(width*scale)||canvas.height!==Math.round(height*scale)){canvas.width=Math.round(width*scale);canvas.height=Math.round(height*scale)}
 ctx.setTransform(scale,0,0,scale,0,0);ctx.clearRect(0,0,width,height);
 const names=['MESSAGE','ENCODER','CHANNEL','DECODER','OUTPUT'],active=visualStage(),left=35,right=width-35,y=80,gap=(right-left)/4;
 ctx.lineWidth=2;ctx.strokeStyle='#c8d9ee';ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(right,y);ctx.stroke();
 names.forEach((name,i)=>{const x=left+i*gap;ctx.beginPath();ctx.arc(x,y,i===active?18:14,0,Math.PI*2);ctx.fillStyle=i<active?'#d9efe6':i===active?'#0875f9':'#e4edfb';ctx.fill();ctx.strokeStyle=i===active?'#70b4ff':'#c3d6f0';ctx.stroke();ctx.fillStyle=i===active?'white':'#285888';ctx.font='bold 11px Segoe UI';ctx.textAlign='center';ctx.fillText(String(i+1),x,y+4);ctx.fillStyle='#35506e';ctx.font=`600 ${width<480?8:10}px Segoe UI`;ctx.fillText(name,x,y+36)});
 if(!visual.data){ctx.font='13px Segoe UI';ctx.fillStyle='#657b95';ctx.fillText('Run a transmission to load its computed signal.',width/2,190);return}
 const d=visual.data,phase=(visual.time/(visual.total/5))%1;
 if(active<4){for(let j=0;j<4;j++){const travel=(phase+j*.25)%1,x=left+(active+travel)*gap;ctx.fillStyle=active===2?'#d88845':'#1983f5';ctx.shadowBlur=7;ctx.shadowColor=ctx.fillStyle;ctx.beginPath();ctx.arc(x,y,3,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0}}
 const waveform=active===2?d.waveform.rx:d.waveform.tx;ctx.strokeStyle=active===2?'#d68a43':'#4b95ee';ctx.lineWidth=1.2;ctx.beginPath();const max=Math.max(1,...waveform.map(Math.abs));for(let i=0;i<Math.min(waveform.length,250);i++){const x=25+i*(width-50)/249,yy=165-waveform[i]*25/max;i?ctx.lineTo(x,yy):ctx.moveTo(x,yy)}ctx.stroke();
 ctx.font='10px Segoe UI';ctx.fillStyle='#5a718e';ctx.fillText(active===2?'Actual noisy samples · first packet':'Actual transmitted samples · first packet',width/2,210);
 ctx.fillStyle='#1670cb';ctx.font='600 11px Segoe UI';ctx.fillText(`Step ${active+1} of 5 · ${d.settings.modulation} · ${d.settings.code==='uncoded'?'No protection':'Code '+d.settings.code} · ${d.settings.ebno_db} dB`,width/2,242);
}
function updateVisualText(){
 const d=visual.data,s=visualStage();document.getElementById('visual-progress').value=String(visual.time);
 document.getElementById('visual-clock').textContent=`${visual.time.toFixed(1)} / ${visual.total} s playback`;
 document.getElementById('visual-play').textContent=visual.playing?'Pause ❚❚':'Play ▶';
 if(!d)return; if(visual.textStage===s)return; visual.textStage=s;
 const descriptions=[`${d.bytes} bytes of your text become ${d.bits} payload bits. We know these original bits, so errors can be counted exactly.`,d.settings.code==='uncoded'?`${d.coded_bits} bits are transmitted without correction redundancy. Interleaving still rearranges the bit order.`:`Convolutional rate ${d.settings.code} coding produces ${d.coded_bits} coded bits including tail overhead. The shown bit sample is after interleaving.`,`${d.symbols} ${d.settings.modulation} symbols are RRC-shaped and disturbed by Gaussian noise. ${d.channel_errors} transmitted bits are incorrect before decoding. Red bits below are actual mismatches in the displayed sample.`,d.settings.code==='uncoded'?`The receiver matched-filters the signal and decides each bit. With no correction code, ${d.errors} payload errors remain.`:`The receiver filters and deinterleaves, then soft Viterbi decoding reconstructs the payload. ${d.errors} payload errors remain; channel and payload counts describe different bit streams.`,d.message_ok?'Every payload bit in this message matches. This is a successful transmission, not proof of the long-run target BER.':`${d.errors} payload bits differ. The damaged output below is reconstructed from those actual received bits.`];
 document.getElementById('visual-title').textContent=captions[s][0];document.getElementById('visual-description').textContent=descriptions[s];
 const row=document.getElementById('visual-bits');row.replaceChildren();let values=s===0?d.tx_bits:s===1?d.trace.transmitted_bits:s===2?d.trace.channel_bits:d.rx_bits;let original=s===2?d.trace.transmitted_bits:s>=3?d.tx_bits:values;
 values.slice(0,32).forEach((v,i)=>{const bit=document.createElement('span');bit.textContent=String(v);if(v!==original[i])bit.className='corrupt';row.append(bit)});
 document.getElementById('visual-bits-label').textContent=s===0?'Sample of original payload bits':s===1?'Sample of actual transmitted coded/interleaved bits':s===2?'Sample of actual channel decisions · red = incorrect transmitted bit':'Sample of decoded payload bits · red = mismatch with original';
 const output=document.getElementById('visual-output');output.hidden=s!==4;output.textContent=`Received message:\n${d.received}`;output.classList.toggle('damaged',!d.message_ok);
}
function tick(clock){if(visual.playing){const delta=visual.lastClock?(clock-visual.lastClock)/1000:0;visual.time=Math.min(visual.total,visual.time+delta);if(visual.time>=visual.total)visual.playing=false;}visual.lastClock=clock;paint();updateVisualText();if(visual.playing)visual.frame=requestAnimationFrame(tick)}
function startPlayback(){if(!visual.data)return;if(visual.time>=visual.total)visual.time=0;visual.playing=true;visual.lastClock=0;cancelAnimationFrame(visual.frame);visual.frame=requestAnimationFrame(tick)}
function loadTransmission(d){cancelAnimationFrame(visual.frame);visual.data=d;visual.textStage=-1;visual.time=0;visual.playing=false;for(const id of ['visual-play','visual-next','visual-restart','visual-progress'])document.getElementById(id).disabled=false;paint();updateVisualText();if(!matchMedia('(prefers-reduced-motion: reduce)').matches)startPlayback()}
document.getElementById('visual-play').addEventListener('click',()=>{if(visual.playing){visual.playing=false;cancelAnimationFrame(visual.frame);updateVisualText()}else startPlayback()});
document.getElementById('visual-next').addEventListener('click',()=>{visual.playing=false;cancelAnimationFrame(visual.frame);visual.time=Math.min(visual.total,(visualStage()+1)*visual.total/5);paint();updateVisualText()});
document.getElementById('visual-restart').addEventListener('click',()=>{visual.time=0;startPlayback()});
document.getElementById('visual-progress').addEventListener('input',e=>{visual.playing=false;cancelAnimationFrame(visual.frame);visual.time=Number(e.target.value);paint();updateVisualText()});
document.getElementById('replay').addEventListener('click',()=>{visual.time=0;startPlayback()});
window.addEventListener('resize',paint);paint();
