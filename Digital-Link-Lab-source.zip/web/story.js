'use strict';
let replayTimer;
function renderStory(d){
 const put=(id,text)=>document.getElementById(id).textContent=text;
 put('sent-text',d.settings.message);
 put('journey-data',`${d.bytes} bytes become ${d.bits} payload bits, split into ${d.packets} packet(s).`);
 put('journey-encode',d.settings.code==='uncoded'?`Protection OFF: ${d.coded_bits} bits are interleaved and sent without redundancy.`:`Rate ${d.settings.code} coding produces ${d.coded_bits} coded bits, including termination. Interleaving rearranges them.`);
 put('journey-channel',`${d.symbols} ${d.settings.modulation} symbols pass through shaping and noise at ${d.settings.ebno_db} dB. ${d.channel_errors} transmitted bits are incorrect before decoding.`);
 put('journey-receive',`${d.bits-d.errors} of ${d.bits} payload bits match after filtering and ${d.settings.code==='uncoded'?'hard decisions':'Viterbi decoding'}. ${d.errors} errors remain.`);
 put('outcome-title',d.message_ok?'Your message arrived intact.':'Noise damaged the recovered message.');
 put('outcome-text',d.message_ok?(d.channel_errors&&d.settings.code!=='uncoded'?`Noise damaged ${d.channel_errors} coded bits, but the decoder reconstructed every payload bit in this message. The longer BER test below measures reliability.`:'Every bit in this message matches. A successful short message demonstrates transmission, but does not establish the target BER.'):`${d.errors} of ${d.bits} payload bits changed (${(100*d.ber).toFixed(2)}%). ${d.settings.code==='uncoded'?'Protection was off. Try “C. Noise + protection” to compare.':'Some errors remain despite protection. Try more signal energy and compare the larger trial.'}`);
 document.getElementById('outcome').classList.toggle('failed',!d.message_ok);
 put('constellation-help',`${d.settings.modulation} uses ${d.settings.modulation==='BPSK'?'two':'four'} ideal states (hollow circles). Noise spreads the blue dots. Crossing decision boundaries can cause errors.`);
 const base=d.comparison.find(x=>x.code==='uncoded'),coded=d.comparison.find(x=>x.code!=='uncoded');
 if(coded&&base){const improvement=base.errors?100*(1-coded.ber/base.ber):null;
 put('comparison-title',improvement===null?'Too few errors to measure a coding benefit.':improvement>0?`Protection reduced measured BER by ${improvement.toFixed(1)}%.`:'This finite trial did not show a coding benefit.');
 put('comparison-story',`Out of ${coded.bits.toLocaleString()} tested bits: uncoded had ${base.errors} errors; coded had ${coded.errors}. ${coded.ber>1e-4?'The coded BER is still above the target of 0.0001.':coded.upper95>1e-4?'The measured BER is low, but the upper bound does not support the target with this sample size.':'Measured BER and nominal upper bound are below 0.0001; correlated decoded errors mean larger independent trials are still needed.'}`);
 }else{put('comparison-title','Use a longer test to assess reliability.');put('comparison-story',base?'Protection is off. Select a code to compare with the uncoded reference.':'Enable BER comparison under Experiment options.');}
 const p=d.power,a=p.assumptions;
 put('power-story',`For the example ${a.distance_m} m link at ${a.carrier_mhz} MHz, your ${d.settings.ebno_db} dB setting maps to ${p.tx_dbm.toFixed(1)} dBm of modeled transmit power. Lower energy can save RF power but introduce more errors. Coding uses extra bits and bandwidth.`);
 const box=document.getElementById('power-values');box.replaceChildren();
 for(const [label,value] of [['Modeled TX power',p.tx_dbm.toFixed(1)+' dBm'],['Required bandwidth',(d.bandwidth_hz/1000).toFixed(1)+' kHz'],['Modeled average power',(p.average_w*1000).toFixed(1)+' mW'],['Illustrative battery life',p.battery_hours.toFixed(1)+' h']]){const div=document.createElement('div'),span=document.createElement('span'),strong=document.createElement('strong');span.textContent=label;strong.textContent=value;div.append(span,strong);box.append(div)}
 put('power-assumptions',`Free-space loss ${p.path_loss_db.toFixed(1)} dB; noise figure ${a.noise_figure_db} dB; margin ${a.margin_db} dB; antenna gain ${a.antenna_gain_total_db} dB. Battery ${a.battery_wh} Wh, ${a.usable_fraction*100}% usable; active circuitry ${a.tx_circuit_w} W; idle ${a.idle_w} W; PA efficiency ${a.pa_efficiency*100}%; traffic ${a.traffic_bps} bit/s; duty cycle ${(p.duty_cycle*100).toFixed(1)}%. No retries or measured processing energy.`);
 document.getElementById('replay').disabled=false;
}
function replayStages(){clearInterval(replayTimer);const stages=['stage-data','stage-encode','stage-channel','stage-receive'];let i=0;const advance=()=>{stages.forEach((id,j)=>document.getElementById(id).classList.toggle('spotlight',j===i));if(++i>stages.length)clearInterval(replayTimer)};advance();replayTimer=setInterval(advance,1300)}
document.getElementById('replay').addEventListener('click',replayStages);
function explainSettings(){const mod=document.getElementById('modulation').value,code=document.getElementById('code').value;document.getElementById('settings-help').textContent=`${mod} carries ${mod==='BPSK'?'one coded bit':'two coded bits'} per symbol. ${code==='uncoded'?'Protection is OFF; no recovery redundancy.':`Rate ${code} sends about ${(1/({'1/2':.5,'2/3':2/3,'3/4':.75}[code])).toFixed(2)} coded bits per payload bit. Extra redundancy costs bandwidth.`}`;}
['modulation','code'].forEach(id=>document.getElementById(id).addEventListener('change',explainSettings));explainSettings();
async function loadStudy(){
 try{
 const response=await fetch('/results/configuration_summary.csv');if(!response.ok)throw Error('Saved study unavailable');
 const lines=(await response.text()).trim().split(/\r?\n/),names=lines.shift().split(',');
 const rows=lines.map(line=>Object.fromEntries(line.split(',').map((value,i)=>[names[i],value])));
 const example=rows.find(r=>r.payload_bytes==='256'&&r.modulation==='BPSK'&&r.code==='1/2');
 const base=rows.find(r=>r.payload_bytes==='256'&&r.modulation==='BPSK'&&r.code==='uncoded');
 document.getElementById('study-conclusion').textContent=`For 256-byte BPSK packets, uncoded transmission required approximately ${Number(base.required_ebno_db).toFixed(2)} dB at BER 0.0001. Rate-1/2 coding required ${Number(example.required_ebno_db).toFixed(2)} dB: a measured coding-gain estimate of ${Number(example.coding_gain_db).toFixed(2)} dB. At equal useful rate and propagation assumptions, this reduces required RF power to about ${(100/10**(Number(example.coding_gain_db)/10)).toFixed(0)}% of the uncoded value. Extra bandwidth and circuit energy must also be considered. These are interpolated finite-sample simulation estimates.`;
 const table=document.createElement('table');const head=document.createElement('tr');for(const title of ['Payload','Modulation','Code','Required Eb/N0','Coding gain']){const th=document.createElement('th');th.textContent=title;head.append(th)}table.append(head);
 for(const r of rows){const tr=document.createElement('tr');for(const value of [r.payload_bytes+' bytes',r.modulation,r.code,r.required_ebno_db?Number(r.required_ebno_db).toFixed(2)+' dB':'Unresolved',r.coding_gain_db?Number(r.coding_gain_db).toFixed(2)+' dB':'Unresolved']){const td=document.createElement('td');td.textContent=value;tr.append(td)}table.append(tr)}document.getElementById('study-table').replaceChildren(table);
 }catch(e){document.getElementById('study-conclusion').textContent='Saved study could not be loaded. Run the full experiment to generate its outputs.';}
}
loadStudy();
