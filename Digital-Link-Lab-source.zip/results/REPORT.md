# Stage 1 simulation results

Generated from actual Monte Carlo runs. No hardware measurements.

Profile: full; 204 BER points; up to 1,200,000 payload bits per point; stop after 200 errors. See CSV for exact counts.

Target crossings are interpolated point estimates, or conservative tested grid points. Confidence intervals are exact binomial intervals; decoded error bursts violate the independence approximation, so intervals are indicative for coded BER. They are not certification. Zero errors are plotted at their upper bound.

Coding: K=7, 171/133 octal, zero-start, six zero tail bits, puncturing, packet permutation interleaving, soft Viterbi. Payload Eb includes termination/padding cost. Sweeps use the equivalent ideal matched-filter symbol model; waveform demo separately implements RRC TX/RX filters and compensated 60 dB attenuation.

Assumptions: perfect timing/carrier/channel-gain knowledge; no fading, interference, preamble, CRC, synchronization acquisition, retries or processing-energy measurement. Source is generated bits (identity source encoding). Stage 2 must add framing and synchronization.

Power example: 915 MHz, 100 m free space, zero antenna gains, 6 dB NF, 3 dB margin; 10 Wh battery with 80% usable energy, .5 W active circuitry, .01 W idle, 25% PA efficiency, 1000 bit/s traffic. All values are assumptions. Recommendations change when these inputs change. Data-rate curves reuse the normalized AWGN measurement, not independent rate simulations.

Lowest modeled average-power candidate: QPSK, code 1/2, 1024 bytes, 100000 bit/s; 0.0149 W, estimated 536.9 h. Provisional: bandwidth/latency constraints and real circuit consumption are unspecified.

Minimum modeled radiated-power candidate: QPSK, code 1/2, 1024 bytes, 10000 bit/s; -50.01 dBm. This is distinct from minimum average electrical power.

## Measured configuration comparison

| Payload bytes | Modulation | Code | Required Eb/N0 dB | Coding gain dB |
|---|---|---|---|---|
| 64 | BPSK | uncoded | 8.38 | 0.00 |
| 64 | BPSK | 1/2 | 3.47 | 4.91 |
| 64 | BPSK | 2/3 | 4.20 | 4.18 |
| 64 | BPSK | 3/4 | 4.47 | 3.91 |
| 64 | QPSK | uncoded | 8.32 | 0.00 |
| 64 | QPSK | 1/2 | 3.37 | 4.95 |
| 64 | QPSK | 2/3 | 4.20 | 4.12 |
| 64 | QPSK | 3/4 | 4.46 | 3.86 |
| 256 | BPSK | uncoded | 8.37 | 0.00 |
| 256 | BPSK | 1/2 | 3.46 | 4.91 |
| 256 | BPSK | 2/3 | 4.22 | 4.16 |
| 256 | BPSK | 3/4 | 4.36 | 4.01 |
| 256 | QPSK | uncoded | 8.34 | 0.00 |
| 256 | QPSK | 1/2 | 3.43 | 4.91 |
| 256 | QPSK | 2/3 | 4.30 | 4.04 |
| 256 | QPSK | 3/4 | 4.35 | 3.99 |
| 1024 | BPSK | uncoded | 8.41 | 0.00 |
| 1024 | BPSK | 1/2 | 3.51 | 4.90 |
| 1024 | BPSK | 2/3 | 4.26 | 4.15 |
| 1024 | BPSK | 3/4 | 4.65 | 3.76 |
| 1024 | QPSK | uncoded | 8.42 | 0.00 |
| 1024 | QPSK | 1/2 | 3.32 | 5.10 |
| 1024 | QPSK | 2/3 | 5.00 | 3.42 |
| 1024 | QPSK | 3/4 | 4.53 | 3.88 |

Consult run_metadata.json for the actual budget settings; defaults can be edited in configs/link_budget.json.
