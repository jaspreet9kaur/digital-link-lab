$env:TEMP='D:\ChatGPT\Temp'
$env:TMP=$env:TEMP
$guard=New-Object System.Threading.Mutex($false,'Local\DigitalLinkLabWatchdog')
if (-not $guard.WaitOne(0)) { exit 0 }
try {
    while ($true) {
        $ready=$false
        try {
            $health=Invoke-RestMethod 'http://127.0.0.1:8765/api/health' -TimeoutSec 3
            $ready=$health.app -eq 'digital-link-lab'
        } catch { }
        if (-not $ready) {
            & 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Start-Background.ps1')
        }
        Start-Sleep -Seconds 10
    }
} finally { $guard.ReleaseMutex(); $guard.Dispose() }
