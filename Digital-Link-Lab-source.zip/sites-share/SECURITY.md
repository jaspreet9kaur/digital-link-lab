# Hosted browser simulation

This build runs locally on the visitor's device using a Web Worker. It does not
send the entered message to a Python backend. The UI preserves the original
Python full-sweep charts as historical results. Live results use a seeded browser
PRNG, so identical seed values do not reproduce Python's NumPy bit/noise streams.
Both engines implement the same coding, modulation and noise normalization.

Functional validation: twelve numerical checks passed: clean message recovery,
Unicode/multiple-packet recovery across eight code/modulation combinations,
independent encoder impulse response, uncoded BER against AWGN theory and coding
improvement at fixed payload energy. Example uncoded QPSK BER at 4 dB over 400,000
bits was 0.01247 versus theoretical 0.01250. Exact binomial upper-bound calculation
for zero errors in 20,000 bits was 0.00018442696, matching SciPy.

## Security baseline
- Source-reviewed: message rendering uses textContent; numerical worker has no
  eval, shell, SQL, uploads, URL retrieval or server mutation endpoints.
- Authentication, CSRF, server rate limits, password storage, MFA, JWT, tenant
  isolation, CORS and webhook signatures are not applicable to this static local
  computation. Hosting audience controls remain enforced by the provider.
- No API keys, real credentials, personal records or package dependencies in dist.
  The compatibility session value is a non-secret marker, not authentication.
- Input byte counts, enumerated settings, trial sizes and a single outstanding run
  are bounded. No localStorage persistence. Exports are user initiated.
- Existing guarded DOM rendering is retained; no newly fetched third-party scripts.
- Dedicated adversarial probes are blocked by unavailable full isolation controls;
  no production-security or penetration-test claim is made.

Private preview remains private until a public audience is explicitly authorized,
or a named external viewer is added with user approval.
