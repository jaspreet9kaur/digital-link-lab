@echo off
cd /d "%~dp0"
set "TEMP=D:\ChatGPT\Temp"
set "TMP=D:\ChatGPT\Temp"
set "NUMBA_CACHE_DIR=%~dp0results\numba-cache"
set "MPLCONFIGDIR=%~dp0results\matplotlib-cache"
"%~dp0.venv\Scripts\python.exe" "%~dp0src\web_app.py" --open
pause
