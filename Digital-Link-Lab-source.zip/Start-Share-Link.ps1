$ErrorActionPreference='Stop'
$env:TEMP='D:\ChatGPT\Temp'
$env:TMP=$env:TEMP
$projectDir=$PSScriptRoot
& 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File (Join-Path $projectDir 'Start-Background.ps1')
if ($LASTEXITCODE -ne 0) { throw 'Local simulation server could not be started.' }
$client='D:\ChatGPT\Downloads\cloudflared-windows-amd64.exe'
if (-not (Test-Path -LiteralPath $client)) {throw 'Official cloudflared client is missing.'}
$log=Join-Path $projectDir ('results\tunnel-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'.log')
$startup=New-CimInstance -ClassName Win32_ProcessStartup -ClientOnly -Property @{ShowWindow=[uint16]0}
$command='"'+$client+'" tunnel --no-autoupdate --protocol http2 --url http://127.0.0.1:8765 --http-host-header digital-link-lab-tunnel --logfile "'+$log+'"'
$created=Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{CommandLine=$command;CurrentDirectory=$projectDir;ProcessStartupInformation=$startup}
if ($created.ReturnValue -ne 0) {throw 'Could not launch sharing tunnel.'}
$origin=$null
for ($attempt=0;$attempt -lt 60;$attempt++) {
    Start-Sleep -Milliseconds 500
    if (Test-Path -LiteralPath $log) {
        $contents=Get-Content -LiteralPath $log -Raw
        $match=[regex]::Match($contents,'https://[a-z0-9-]+\.trycloudflare\.com')
        if ($match.Success) {$origin=$match.Value;break}
    }
}
if (-not $origin) {throw "No sharing URL was issued. Check $log"}
$keyBytes=New-Object byte[] 32
$rng=[System.Security.Cryptography.RandomNumberGenerator]::Create()
$rng.GetBytes($keyBytes);$rng.Dispose()
$key=([BitConverter]::ToString($keyBytes)).Replace('-','').ToLowerInvariant()
$cfg=@{origin=$origin;key=$key;tunnel_pid=$created.ProcessId}
$cfg | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $projectDir '.share-access.json') -Encoding utf8
$link=$origin+'/?access='+$key
Set-Content -LiteralPath (Join-Path $projectDir 'results\share-link.txt') -Value $link -Encoding utf8
Write-Output $link
