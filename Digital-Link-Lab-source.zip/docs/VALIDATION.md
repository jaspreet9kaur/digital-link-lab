# Stage 1 validation — 14 October 2026

Executed `.venv\Scripts\python.exe -m unittest discover -s tests -v`:
all five tests passed. Tests cover an independently specified encoder impulse
response, noiseless round trips for all four coding options and both modulations
at multiple lengths, noise scaling against theoretical uncoded BER, coding benefit
at fixed payload Eb/N0, and RRC matched-filter delay/recovery.

Executed `src\simulate.py --profile full`: completed successfully.
- 204 Monte Carlo operating points.
- 143,737,344 payload bits tested across the points.
- Both BPSK and QPSK; uncoded / rate-1/2 / punctured-2/3 / punctured-3/4.
- Payload sizes 64, 256 and 1024 bytes.
- All 24 configuration curves yielded target-crossing point estimates.
- 256-byte BPSK rate-1/2 estimated coding gain: 4.91 dB at BER 1e-4.
- Separate noisy RRC-shaped QPSK demonstration: 0 errors in 2048 bits.
- BER curves and waveform demo visually inspected after generation.

These are seeded finite-sample results, not hardware certification. Some high-SNR
points observed zero errors; the plots use a 95% upper bound at those points.
Nominal bit confidence intervals assume independent errors; convolutional decoding
can create correlated bursts. Larger repeated-seed runs are appropriate before
claiming a precise optimal operating point or statistical compliance.

Source reviewed security categories and current dependency advisory scan are
recorded in SECURITY.md. Dedicated dynamic security probes were not executed.

Source design references:
- https://www.mathworks.com/help/comm/ug/convolutional-codes.html
- https://www.mathworks.com/help/comm/ug/awgn-channel.html

MATLAB documentation is used as a technical reference, not as a runtime dependency.
