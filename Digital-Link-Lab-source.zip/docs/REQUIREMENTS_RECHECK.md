# Original brief compliance review — 16 October 2026

Re-read reference/project-brief.jpeg directly and checked code, generated outputs,
public hosted version 1 and current tests. Eleven Python tests passed on recheck.
This is a source-and-output compliance review, not new hardware validation.

| Slide requirement | Current evidence | Status / limits |
|---|---|---|
| Sensor / digital data | Text UTF-8 payload and generated known bits | Digital input implemented; no physical sensor |
| Source encoder | UTF-8 for text; identity for generated bits | Basic representation; no compression codec |
| Convolutional or LDPC encoder | K=7, 171/133, punctured 1/2, 2/3, 3/4 | Convolutional option implemented; LDPC alternative not implemented |
| Interleaver | Seeded packet permutation and inverse | Implemented |
| BPSK/QPSK mapping | Both in Python and browser worker | Implemented |
| RRC pulse shaping | Sample-domain live message + separate waveform demo | Implemented; full BER sweeps use ideal matched-filter symbol equivalent |
| Path loss + AWGN | AWGN in live channel; path loss in link budget and compensated fixed-loss waveform demo | Modeled with ideal channel knowledge; no measured propagation |
| Demodulation and Viterbi decoding | Hard decisions / soft Viterbi | Implemented; ideal timing/carrier knowledge |
| Recovered data + BER | Text, bit mismatch counts and trials | Implemented |
| Sweep power/modulation/code/packet | 204 Python Eb/N0 points; modeled power conversion | Implemented for simulation route; no hardware gain sweep |
| Coding gain at BER 1e-4 | Configuration table and uncoded reference | Finite-sample target-crossing estimates, not certified compliance |
| Required power vs modulation/code at fixed BER | power_tradeoffs.csv | Modeled from estimated crossings |
| Required Eb/N0 vs data rate | rate_tradeoffs.png, 10/50/100 kbit/s budget calculations | Normalized AWGN curves reused; not separate physical rate experiments |
| Required Eb/N0 vs packet size | packet_tradeoffs.png, 64/256/1024-byte sweep | Present; no framing/preamble/CRC or retries |
| One justified low-power operating point | REPORT.md minimum-RF and minimum-average-power candidates | Provisional; no agreed bandwidth/latency limits; needs one defended final selection |
| Link budget | Explicit example assumptions, equations in code, CSV power values | Modeled; final report needs a worked calculation |
| Battery-life estimate | Duty/circuit/PA model, 10 Wh example | Assumption-based; processing, RX activity and retransmissions not modeled in full |
| Configuration tradeoff table | CSV and hosted summary | Present |
| BER curves showing coding gain | ber_curves.png + summary | Present; uncertainty noted |
| Report and demo | Results Markdown, web demonstration, animation | Working demo present; formal submission report not completed |
| PC/laptop >=8GB | User reports 16GB laptop | Available |
| Optional Pluto or HackRF programmable TX | No hardware integration; lab bladeRF/RTL identified | Deferred Stage 2; no Pluto/HackRF implementation |
| DC supply or USB meter | No measured current data | Deferred Stage 2 |
| Battery pack demo | No physical battery test | Deferred Stage 2 |
| MATLAB/Simulink Communications Toolbox | Not used | Listed tool not literally fulfilled; Python/browser implementation substituted |
| GNU Radio Companion 3.10 | No radio flowgraph created | Deferred hardware software; not literally fulfilled |
| Python3 NumPy SciPy Matplotlib | Local .venv, code, generated results | Implemented; hosted live engine separately ported to JS worker |
| Software TX gain dB steps | Eb/N0 model only | Physical SDR gain control not implemented |
| Conducted SMA TX/RX link | No connected equipment | Deferred Stage 2 |
| Current logged at every gain step | No instrument integration | Deferred Stage 2 |
| CSV export | Raw BER/configuration/power CSV | Implemented; live individual run exports JSON |
| Simulation-only route: transmit power as Eb/N0 | Python sweeps and browser energy control | Implemented |

## Important interpretation
The brief explicitly offers a simulation-only route. Hardware measurements therefore
remain a separate phase by user agreement. The listed software names are not proof
that all three platforms must be used simultaneously, but replacements must be
stated honestly. Instructor acceptance of tool substitutions is not established.

## Remaining work before a strong final submission
1. Choose and defend ONE final operating point under stated throughput, bandwidth,
   latency and channel assumptions. Avoid selecting BPSK/QPSK based on Monte Carlo
   scatter where their ideal AWGN performance should be equivalent.
2. Refine target crossings and repeat independent seeds near BER 1e-4; explain
   uncertainty and correlated decoded errors.
3. Write a formal report with a worked link budget, methodology, figures, table,
   recommendation and battery assumptions/limits. Make that report accessible in UI.
4. State symbol-domain sweep versus sample-domain message demonstration explicitly.
5. If hardware is later required: bladeRF/RTL setup, attenuation, framing/acquisition,
   gain calibration, current logs and measured battery/power comparison remain.

Do not describe the project as having implemented every hardware/software item
on the slide, or as proving days of battery operation.
