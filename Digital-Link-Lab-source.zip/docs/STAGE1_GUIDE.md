# How to demonstrate Stage 1

1. Open results/waveform_demo.png. Explain that generated payload bits are encoded,
   interleaved and mapped into QPSK symbols. RRC filtering shapes the transmitted
   waveform. The channel adds attenuation and noise. A matched filter extracts
   symbols and the Viterbi decoder recovers payload bits.
2. Open results/ber_curves.png. The dotted theoretical curve validates the uncoded
   model. A lower curve means fewer errors for the same payload-bit energy.
3. Open results/configuration_summary.csv. At BER 1e-4, coding gain is uncoded
   required Eb/N0 minus coded required Eb/N0, measured in dB. Target estimates
   have sampling uncertainty; inspect error/bit counts in ber_measurements.csv.
4. Open results/rate_tradeoffs.png and packet_tradeoffs.png. In ideal AWGN the
   normalized energy requirement does not depend on absolute data rate. Finite
   packet coding overhead and statistics can affect packet comparisons.
5. Open results/power_battery.png and power_tradeoffs.csv. Link-budget assumptions
   convert energy requirements into modeled watts. Electrical consumption also
   includes circuitry and duty cycle. These values are estimates, not SDR readings.
6. Read results/REPORT.md before presenting a recommendation. A lower radiated
   power setting need not be the setting with minimum average battery consumption.

## Requirements traceability
| Brief item | Implementation / evidence |
|---|---|
| Coded BPSK/QPSK | src/link.py; all four coding options measured for both modulations |
| Convolutional OR LDPC | Convolutional K=7, 171/133; soft Viterbi; LDPC not required by OR |
| Interleaving | Reproducible packet permutation and exact inverse |
| RRC / channel / receiver | Sample-domain waveform demo; sweeps use ideal symbol-domain equivalent |
| Source data / recovery / BER | Generated bits, identity source encoder, recovered payload and error counts |
| Power/modulation/code/packet sweep | Raw Eb/N0 grid and modeled TX-power conversion, 3 payload sizes in full run |
| Data-rate comparisons | 10/50/100 kbit/s link-budget calculation; AWGN-normalized curves reused |
| Coding gain at 1e-4 | configuration_summary.csv; unresolved crossings labeled honestly |
| Configuration-power table | power_tradeoffs.csv |
| Recommended point / link budget / battery | REPORT.md and editable configs/link_budget.json |
| Report and demo | CSV/PNG/NPZ outputs, REPORT.md, two Windows run launchers |

## Stage 2 extension
Use bladeRF TX and RTL-SDR RX if their confirmed models support a shared frequency.
Add a packet preamble/header/CRC, acquisition, frequency/timing correction, radio
drivers, safe attenuation, RF gain calibration and DC current measurement.
Stage 1 does not validate those physical-device functions.
