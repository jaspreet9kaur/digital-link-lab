# Digital Link Lab: visible demonstration

Open http://127.0.0.1:8765 while the server runs. To start later, double-click
Start-Link-Lab.cmd. Keep its terminal open; Ctrl+C stops it. No ChatGPT or Internet
account is required to operate the app.

## Demo sequence
1. Enter a message and click Clean channel; show the recovered message and plots.
2. Click Noisy, uncoded; show damaged text and red bit mismatches.
3. Click Same noise, coded; compare the recovered message and larger BER trial.
4. Change settings or seed and rerun. Results are computed, not scripted successes.
5. Open BER & tradeoffs for the saved 204-point full sweep and CSV downloads.
6. Open How it works for the processing explanation.

## Executed verification
All nine numerical tests passed, including Unicode, multiple-packet recovery,
repeatability and rate scaling. Browser default recovered 288 bits with zero
payload errors after 32 coded-channel bit errors at 4 dB. The 2 dB uncoded preset
produced 12 payload errors and damaged text; coded preset recovered that message.
Its independent 20,000-bit trial measured 745 uncoded versus 136 coded errors.
The BER results view opened with its plots and links. Screenshot: web-app-preview.png.

Message simulation uses RRC TX filtering, sample-domain Gaussian noise, matched
filtering and decoding. Optional BER trials use the symbol-domain equivalent.
Timing and carrier knowledge are ideal. Duration/bandwidth change with data rate;
normalized AWGN BER does not. Saved full-sweep plots are separate historical
results. Power and battery figures remain modeled. Security review: SECURITY.md.

## Guided page and direct browser access
Open http://127.0.0.1:8765/ directly in Chrome. The hidden server starts at Windows
sign-in through the Digital Link Lab.lnk shortcut in the user Startup folder.
No CMD is needed for normal use. The laptop must be on and signed in. HTTPS is not
configured. If the process stops unexpectedly, Start-Background.ps1 can restart it.
All ten numerical tests passed after adding the live modeled link budget. Browser
verified the input/output journey, noisy-message explanation, coding recovery and
full-study coding-gain narrative. Startup script execution and HTTP health passed;
a reboot/sign-in-cycle test remains unperformed. Updated screenshot: guided-preview.png.
To disable automatic startup, remove only Digital Link Lab.lnk from the Windows
Startup folder; project data and the app files remain on D:.
