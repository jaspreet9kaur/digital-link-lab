# Requirements and proposed solution

## Requirements transcribed from the supplied slide
Title: Low-Power Digital Link for Soldier and Vehicle Nodes. Project 3 of 5, Group 3.
Defence application: soldier-worn radios, vehicle nodes and unattended ground sensors that must run for days on a single battery.

Problem: Increasing transmit power improves BER but drains the battery. Determine the combination of modulation order, coding rate, data rate and packet size that meets a target BER at the lowest transmitted power.

Block diagram:
Sensor/digital data -> source encoder -> channel encoder (convolutional/LDPC) -> interleaver -> BPSK/QPSK mapper and RRC shaping -> wireless channel (path loss + AWGN) -> demodulator -> channel decoder (Viterbi/BP) -> recovered data and BER.
The slide identifies transmit power as the input variable of the mapper output. Receiver matched filtering and deinterleaving must also be included when implementing the corresponding transmitter blocks.

Objectives:
- Build a coded BPSK/QPSK link using convolutional coding with Viterbi decoding OR LDPC coding.
- Systematically sweep transmit power, modulation, code rate and packet size. The problem and expected plots also require data-rate sweeps.
- Measure coding gain in dB at BER = 1e-4.
- Recommend one operating point with a simple link budget.

Expected outcomes and deliverables:
- Configuration versus required power table for modulation and code rate at a fixed BER.
- BER curves and coding gain relative to an uncoded reference.
- Required Eb/N0 plotted against data rate and packet size.
- A justified low-power operating point with estimated battery life.
- Report and demonstration.

Listed hardware:
- PC/laptop with at least 8 GB RAM.
- Optional ADALM-PLUTO or HackRF with programmable TX gain.
- Bench DC supply with current readout OR USB power meter; battery pack for demonstration.

Listed software:
- MATLAB/Simulink with Communications Toolbox.
- GNU Radio Companion 3.10.
- Python 3 with NumPy, SciPy and Matplotlib for sweep scripts.
These are listed tools; the slide does not explicitly establish that all three must be used. Confirm the course's required submission platform before committing to a MATLAB-only or Python-only implementation.

Listed interface details:
- Software TX gain in dB steps; conducted SMA link to receiving SDR.
- Current logged at every gain step using the supply or USB meter.
- Sweep results exported to CSV.
- Simulation-only route models transmit power through Eb/N0.

## Proposed implementation and why
1. Establish uncoded BPSK and Gray-coded QPSK over AWGN. Check against analytical BER. This validates noise scaling before measuring coding gain.
2. Add a standard rate-1/2 convolutional code, proposed constraint length 7 and generators 171/133 octal, terminated per packet, with soft-decision Viterbi decoding. This is a practical first coding option; LDPC is an alternative, not an additional mandatory implementation.
3. Add rate-2/3 and rate-3/4 puncturing with documented patterns, interleaving/deinterleaving, framing and RRC transmit/receive filtering. Check noiseless decoding and delay/bit alignment first.
4. Sweep modulation, coding rate, useful data rate and payload size. Proposed initial payloads: 64, 256 and 1024 bytes; useful rates: 10, 50 and 100 kbit/s. These values are design choices, not values prescribed by the image. Refine the Eb/N0 grid around the target crossing.
5. Export raw error counts and bit counts, BER, packet error rate, effective rate, occupied bandwidth, required Eb/N0 and modeled transmit power. Measure coding gain at equal useful-bit Eb/N0 definition and BER.
6. Build an explicit link budget and energy model, then select the lowest-energy feasible point meeting BER, throughput, bandwidth and latency constraints. Also report the minimum-radiated-power point because the slide explicitly asks for it.
7. If hardware is available, implement the chosen waveform and conducted experiment, calibrate gain-to-RF-power conversion, log voltage/current, and compare measured behavior with simulation.

## Fair comparison and evidence
Define Eb using useful payload bits. Account for parity, termination, preamble, CRC and QPSK padding in the effective rate. Keep useful throughput and channel assumptions comparable. For ideal AWGN, uncoded BPSK and Gray QPSK have the same BER versus Eb/N0; QPSK primarily changes bandwidth efficiency. Do not manufacture separate coding gains from inconsistent normalization.

At BER 1e-4, about 1 million tested bits yield only about 100 expected errors. Use a target error count plus a maximum-bit cap, record confidence intervals and multiple independent seeds. Zero observed errors is an upper-bound observation, not proof of zero BER. If a curve does not establish the target crossing, mark it unresolved rather than extrapolating a claimed result.

Required Eb/N0 may be unchanged by useful data rate in an ideal normalized model. Data rate still changes required watts through energy per bit. Packet size affects termination/framing overhead, latency, packet error rate and retransmission energy. Plot real measured dependencies, including flat ones.

## Link budget and battery model
For a consistently defined useful bit rate Rb:
Required received power (dBm) = -174 + 10*log10(Rb) + receiver noise figure + required Eb/N0 (dB) + implementation margin, at approximately 290 K.
Required TX power (dBm) = required received power + path/cable losses - TX antenna gain - RX antenna gain.
Choose frequency, range, noise figure, losses and margin explicitly; these are currently unknown. Never present arbitrary example assumptions as measured values.

Average electrical power must include idle/sleep consumption, active TX circuitry, PA efficiency, receiver activity, processing, duty cycle and retries. Battery life (hours) = usable battery energy (Wh) / average electrical power (W). Include voltage, capacity and a usable-energy factor. SDR bench measurements demonstrate the equipment's consumption; they do not establish that a miniaturized soldier node runs for days.

## Software and equipment decisions
Free starting route: existing Python plus NumPy/SciPy/Matplotlib in a project virtual environment. MATLAB/Simulink with Communications Toolbox is suitable if the institution supplies a license. GNU Radio 3.10 is useful for an SDR demo; install it when the radio and host integration path are known.

Simulation requires no SDR, Arduino or external sensor. Known pseudorandom payloads provide a reproducible BER reference.

Preferred lab demo: one ADALM-PLUTO can transmit and receive simultaneously for a bench loopback; two radios better represent two separate nodes. HackRF One is half duplex, so a simultaneous physical link requires a second compatible receiver/transceiver.

Borrow USB cables, 50-ohm SMA cable(s), correctly rated fixed/variable attenuators, USB power meter or regulated supply with current measurement, and a suitable battery pack. Determine attenuation from the actual transmitter power and receiver input limits before wiring; do not connect TX directly to RX without that check. A USB meter measures DC input power, not radiated RF output. An RF power meter or calibrated spectrum analyzer is useful for calibrated RF measurements.

## Current state and information needed next
The D: project scaffold and reference copy exist. Environment checker confirms missing numerical libraries. No simulation has been implemented or executed.
Need course platform requirements, MATLAB license availability, lab SDR models/counts, whether hardware is mandatory, deadline, and eventual range/throughput/battery targets. Initial simulation design can proceed with explicitly documented provisional choices.

## Primary references
- Convolutional coding: https://www.mathworks.com/help/comm/ug/convolutional-codes.html
- BER analysis: https://www.mathworks.com/help/comm/ug/bit-error-rate-analysis-techniques.html
- Pluto hardware: https://www.analog.com/en/resources/evaluation-hardware-and-software/evaluation-boards-kits/adalm-pluto.html
- HackRF One: https://greatscottgadgets.com/hackrf/one/
- GNU Radio Windows installation: https://wiki.gnuradio.org/index.php/WindowsInstall
- Python downloads: https://www.python.org/downloads/windows/

## User update: initial equipment availability
The user currently has a PC and reports basic SDRs and an antenna described as "ALpha one" in the lab. Exact radio model, quantity, transmit capability and antenna specification remain unknown. MATLAB licensing is not yet established. MATLAB is PC software, not hardware. MATLAB Online basic offers limited free use; do not assume Communications Toolbox is included. A trial or institutional license is another possible route. The Python simulation remains the proposed free route.
