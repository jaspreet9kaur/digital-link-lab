# Minimum bench setup

Use the existing laptop, one bladeRF as TX, one RTL-SDR as RX, and the lab spectrum analyzer. No second transmitter or antenna is needed for the conducted demonstration.

- Confirm the two SDR model labels, connectors and shared tuning range. Use their existing compatible USB data cables.
- Borrow 50-ohm SMA coax, any mating adapters, and a fixed or step attenuator that covers the test band. The lab must choose attenuation from the actual maximum TX level and the lower of the RX/analyzer safe-input limits, with headroom. Do not directly connect an unattenuated TX. Check that bias tee is off; ask the lab about a DC block if the port supplies DC.
- Borrow one data-pass-through USB power meter if the transmitter is USB powered, or an appropriate metered regulated supply if it supports separate DC power. Keep the host data connection intact. Measure the TX node first; measure RX separately if reporting both.
- Borrow a compatible battery pack for the slide's physical battery demo. Verify the exact supply voltage, connector, current rating, and battery Wh. A battery powering an SDR does not make the laptop-controlled node standalone.
- Use the existing analyzer or a calibrated RF power meter to measure mean RF power over the occupied channel. Record cable/pad losses and instrument settings separately. Do not label a software gain setting as RF dBm.
- Install model-compatible bladeRF/RTL drivers and use GNU Radio Companion 3.10 or an equivalent capture/control chain. No flowgraph has yet been verified against these devices. MATLAB is not required for the Python simulation route.

## Bench acceptance sequence

1. Identify hardware, confirm safe conducted wiring with the lab, and verify both devices enumerate. Leave the transmitter disabled until the RF path has been checked.
2. Confirm sample capture and packet synchronization with known data; compare received bits with sent bits. Keep receiver gain, bandwidth, cabling and payload rate fixed for comparisons. Report missed frames separately so received-only BER does not hide lost packets.
3. At each planned TX gain setting, record calibrated RF output, supply voltage/current, attempted and received packets, tested payload bits and errors. Compare uncoded versus coded using identical payload rate, packet size and measurement conditions.
4. For battery demonstration, verify battery operation and measure active/idle power. Estimate runtime from usable Wh divided by measured duty-weighted watts. Label it an estimate unless a full discharge test was performed.

Log fields: device models | test frequency | modulation | code | payload bytes | payload bit rate | TX gain | calibrated RF dBm | attenuation | RX gain | supply V | TX A | attempted packets | received packets | payload bits tested | errors | BER | notes.

Pending: exact radio/meter models, attenuation selection, actual driver/flowgraph integration, conducted measurements, current logs and battery demo.
