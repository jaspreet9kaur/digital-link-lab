$ErrorActionPreference = 'Stop'
$projectDir = $PSScriptRoot
$env:TEMP = 'D:\ChatGPT\Temp'
$env:TMP = $env:TEMP
$env:NUMBA_CACHE_DIR = Join-Path $projectDir 'results\numba-cache'
$env:MPLCONFIGDIR = Join-Path $projectDir 'results\matplotlib-cache'
try {
    $health = Invoke-RestMethod 'http://127.0.0.1:8765/api/health' -TimeoutSec 3
    if ($health.app -eq 'digital-link-lab') { exit 0 }
} catch { }
$pythonExe = Join-Path $projectDir '.venv\Scripts\python.exe'
$serverScript = Join-Path $projectDir 'src\web_app.py'
$stdoutLog = Join-Path $projectDir 'results\server-output.log'
$stderrLog = Join-Path $projectDir 'results\server-error.log'
$serverProcess = Start-Process -FilePath $pythonExe -ArgumentList @('"' + $serverScript + '"') -WorkingDirectory $projectDir -WindowStyle Hidden -RedirectStandardOutput $stdoutLog -RedirectStandardError $stderrLog -PassThru
for ($attempt=0; $attempt -lt 20; $attempt++) {
    Start-Sleep -Milliseconds 500
    try {
        $health = Invoke-RestMethod 'http://127.0.0.1:8765/api/health' -TimeoutSec 2
        if ($health.app -eq 'digital-link-lab') { exit 0 }
    } catch { }
    if ($serverProcess.HasExited) { throw "Local server exited. See $stderrLog" }
}
throw "Server did not become ready. See $stderrLog"
