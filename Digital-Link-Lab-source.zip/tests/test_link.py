import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import unittest
import numpy as np
from scipy.special import erfc
from scipy.signal import upfirdn
from link import encode, prepare, recover, packet, PATTERNS, rrc

class LinkTests(unittest.TestCase):
    def test_independent_encoder_vector(self):
        # Impulse response: generator coefficients, then terminated zeros.
        self.assertEqual(encode(np.array([1],dtype=np.uint8)).tolist(),
                         [1,1,0,1,0,0,1,1,1,1,1,0,1,1])

    def test_noiseless_all_codes_and_modulations(self):
        rng=np.random.default_rng(42)
        for n in [1,17,512,2048]:
            bits=rng.integers(0,2,n,dtype=np.uint8)
            for code in PATTERNS:
                for mod in ['BPSK','QPSK']:
                    tx,mask,perm,count,rate=prepare(bits,code,mod,rng)
                    np.testing.assert_array_equal(bits,recover(tx,code,mod,mask,perm,count))
                    self.assertAlmostEqual(np.sum(abs(tx)**2)/n,1/(rate*(1 if mod=='BPSK' else 2)))

    def test_uncoded_awgn_theory(self):
        for mod in ['BPSK','QPSK']:
            rng=np.random.default_rng(543)
            bits=rng.integers(0,2,400000,dtype=np.uint8)
            decoded,*_=packet(bits,'uncoded',mod,4,rng)
            observed=np.mean(decoded!=bits)
            theory=.5*erfc(np.sqrt(10**.4))
            self.assertLess(abs(observed-theory),5*np.sqrt(theory*(1-theory)/len(bits)))

    def test_coding_improves_ber(self):
        rng=np.random.default_rng(56)
        errors={'uncoded':0,'1/2':0}
        for _ in range(100):
            bits=rng.integers(0,2,2048,dtype=np.uint8)
            for code in errors:
                decoded,*_=packet(bits,code,'BPSK',4,rng)
                errors[code]+=np.count_nonzero(decoded!=bits)
        self.assertLess(errors['1/2'],errors['uncoded']/3)

    def test_rrc_matched_filter(self):
        rng=np.random.default_rng(78)
        bits=rng.integers(0,2,2048,dtype=np.uint8)
        h=rrc()
        self.assertAlmostEqual(np.sum(h*h),1)
        for mod in ['BPSK','QPSK']:
            tx,mask,perm,count,_=prepare(bits,'3/4',mod,rng)
            wave=upfirdn(h,tx,up=8)
            filtered=np.convolve(wave,h)
            samples=filtered[len(h)-1:len(h)-1+8*len(tx):8]
            self.assertLess(np.max(abs(samples-tx)),.04)
            np.testing.assert_array_equal(bits,recover(samples,'3/4',mod,mask,perm,count))

if __name__=='__main__': unittest.main()
