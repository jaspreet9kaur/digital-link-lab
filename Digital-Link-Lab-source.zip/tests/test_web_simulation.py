import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
import unittest
from web_app import simulate

class WebNumericalTests(unittest.TestCase):
    def config(self,**extra):
        return dict(message='PC lab: signal received. नमस्ते',modulation='QPSK',code='1/2',
                    packet_bytes=64,rate_bps=50000,trial_bits=0,seed=42,ebno_db=14,**extra)
    def test_utf8_message_round_trip(self):
        result=simulate(self.config())
        self.assertEqual(result['received'],result['settings']['message'])
        self.assertEqual(result['errors'],0)
    def test_multiple_packets_both_modulations(self):
        for mod in ['BPSK','QPSK']:
            c=self.config();c['message']='Testing the packet boundary. '*20;c['modulation']=mod
            r=simulate(c)
            self.assertGreater(r['packets'],1)
            self.assertEqual(r['received'],c['message'])
            self.assertEqual(r['bits'],len(c['message'].encode())*8)
    def test_repeatable_and_data_rate(self):
        c=self.config();c['ebno_db']=2
        a=simulate(c);b=simulate(c)
        self.assertEqual(a['rx_bits'],b['rx_bits'])
        c['rate_bps']=100000;d=simulate(c)
        self.assertEqual(a['rx_bits'],d['rx_bits'])
        self.assertAlmostEqual(a['duration_ms']/2,d['duration_ms'])
    def test_comparison_counts(self):
        c=self.config();c['trial_bits']=20000;c['ebno_db']=4
        r=simulate(c)
        self.assertEqual([x['bits'] for x in r['comparison']],[20000,20000])
        self.assertLess(r['comparison'][1]['errors'],r['comparison'][0]['errors'])
    def test_link_budget_energy_scaling(self):
        c=self.config();c['ebno_db']=4
        a=simulate(c);c['ebno_db']=7;b=simulate(c)
        self.assertAlmostEqual(b['power']['tx_dbm']-a['power']['tx_dbm'],3)
        self.assertGreater(b['power']['average_w'],a['power']['average_w'])
        self.assertLess(b['power']['battery_hours'],a['power']['battery_hours'])
    def test_visual_trace_matches_channel_error_count(self):
        c=self.config();c['message']='A';c['ebno_db']=2
        r=simulate(c);trace=r['trace']
        self.assertEqual(len(trace['transmitted_bits']),r['coded_bits'])
        self.assertEqual(sum(a!=b for a,b in zip(trace['transmitted_bits'],trace['channel_bits'])),r['channel_errors'])

if __name__=='__main__': unittest.main()
